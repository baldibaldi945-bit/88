# ModBridge — AxelzeroX23

**Android toolkit for converting supported Friday Night Funkin' mod archives to and from Psych Engine, editing stage JSON, and optimizing image assets.**

ModBridge runs the conversion on the device after installation. It does not upload a user's mod archive to a server.

## Included source converters

- **V-Slice → Psych Engine**: converts supported charts and selected character/stage data, BPM changes, camera-focus events, and known chart events.
- **Codename Engine → Psych Engine**: converts supported charts, character XML, stage XML, and recognizable events.
- **Funky Maker Mobile (FNMM) → Psych Engine**: converts supported charts and character/stage descriptors.

ZIP and 7Z input archives are accepted. Nested ZIP/7Z archives are unpacked with depth and size limits. The app limits a selected archive to 256 MB, a single extracted entry to 128 MB, and total extracted content to 512 MB to reduce memory-exhaustion risk on phones. The app rejects unknown source layouts rather than returning a misleading "successful" conversion.

## App features in 1.5.1

- Algerian Arabic, Standard Arabic, English, Portuguese, Japanese, and Thai UI.
- Light/dark appearance, touch pointer, animated page transitions, button sounds, and background music paused/resumed with Activity lifecycle.
- On-device conversion library for recent outputs.
- **Image Optimizer**: one image per operation; PNG, WebP, JPEG, and GIF output. Supports resizing, selectable white/black flattening backgrounds, alpha preservation for PNG/WebP/GIF, indexed PNG quantization at lower quality settings, and animated-GIF frame sampling. PNG quality below 100 uses a reduced indexed palette and therefore is lossy; quality 100 uses regular lossless PNG. GIF uses a compact fixed palette and can reduce colour detail.
- **Live Stage Editor (1.6.0)**: opens a Psych ZIP with a live Canvas preview of the stage and characters; drag objects/characters/camera points, add/remove/replace sprites and GIFs (GIFs become Sparrow sprites on save), replace characters, flip chart sides per page, import arrow/splash skins and health bar frames, then saves a new ZIP. Runs on Android 5.0+. The preview approximates Psych; see CHANGELOG-1.6.0-AR.md for limits.
- **Psych → FNMM reverse conversion**: creates a separate `.FNMM` archive per discovered chart/difficulty, maps 4-lane chart notes into the reference `strumLines` structure, copies available OGG audio, crops Sparrow characters and stage sprites into horizontal FNMM strips (one image per animation as in the supplied sample), and exports two-frame health icons when source icon sheets are present.
- **Script Lab**: accepts text/code and ZIP archives for static diagnostics and local example lookup. The knowledge retrieval index includes both the archived source examples and the standalone Sprite Map/FNMM format references. Image and audio attachments expose metadata only; there is no offline computer-vision model or speech transcription. This is a rule-based helper, not an LLM.
- The supplied `My-Mod` Psych template is merged into forward-conversion output without overwriting converted files; required Psych containers and a Freeplay-only week are always added.

## Conversion details

| Mod content | Current behaviour |
|---|---|
| Charts | Writes Psych chart JSON with supported notes, sustains, difficulties, BPM changes, and event mappings. |
| Characters | Converts supported Codename XML, V-Slice JSON, and FNMM descriptors to Psych character JSON. |
| Stages | Converts supported stage data to Psych stage JSON/Lua, including known props, positions, zoom, scale, scroll, and draw order. |
| Events | Maps recognized timing, BPM, camera, flash, animation, and related event fields. Unrecognized event types are reported. |
| FNMM sprite builder | Splits horizontal PNG strips according to `sprite.json`, packs frames into Sparrow PNG/XML atlases, and creates character JSON when the descriptor is valid. Original strips are removed only after a complete atlas is created. |
| Script migration | An offline rules-based helper translates a limited set of recognizable Haxe/HScript patterns into Psych Lua. |
| Shaders | Keeps shader files referenced by generated Lua and can remove unused ones. This is not a shader-language transpiler. |
| Audio/images/fonts | Copies compatible assets found in the source archive into Psych-style folders where their paths can be identified. |

### Important limitations

- The offline Script Lab is **not a large language model**. It uses deterministic local rules and lexical example retrieval, does not execute source code, and does not invent equivalents for unknown Haxe/Flixel logic. ZIP code files are extracted for inspection; images/audio are metadata-only attachments.
- V-Slice custom note styles can declare separate `note`, `noteStrumline`, `holdNote`, `noteSplash`, and `holdNoteCover` assets. These are not automatically merged into a verified Psych `NOTE_assets`/splash atlas by this version. The converter records a warning when a non-default note style is detected. Do not assume custom V-Slice arrows, hold covers, or splashes have been converted; verify them in the target Psych Engine build.
- Custom engine states, menus, proprietary formats, unknown mechanics, and every shader/event combination cannot be guaranteed to convert.
- Password-protected archives are not supported by the current file picker/conversion flow.
- Psych→FNMM is a best-effort structural converter, not a lossless port. FNMM event actions are not inferred unless a known mapping exists; source events/Lua are retained as references and warnings. Custom notes, Haxe logic, shader logic, and arbitrary Lua state are not made runnable by this reverse converter.
- The Image Optimizer uses Android `Movie` for GIF decoding. GIF variable delays/disposal may be approximated; the output is capped to sampled frames. PNG quantization below 100 changes palette/alpha precision. Avoid using it on a master asset when exact pixels are required.
- Archive processing and image decoding retain explicit safety limits because a phone has finite RAM. Large/unbounded input cannot be promised safe on a 4 GB device.
- Always test the resulting ZIP in the exact engine version you use. Review `conversion-report.txt` and keep the source backup option enabled when experimenting with a valuable mod.

See **[GITHUB_GUIDE_AR.md](GITHUB_GUIDE_AR.md)** for the same upload and APK steps in Arabic.

## Build the APK with GitHub Actions

1. Extract this project ZIP on your computer.
2. Create a new repository on GitHub and upload the **contents** of the extracted `ModBridge` folder (the root should contain `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `core/`).
3. Push the files to the `main` branch, or use the repository's **Actions** tab and run **Build ModBridge APK** manually.
4. Open the completed workflow run and download the artifact named **ModBridge-debug-apk**.
5. Inside the artifact is `app-debug.apk`.

The workflow runs the core tests and `assembleDebug`. This produces a **debug APK** for testing, not a release-signed Play Store APK.

## Build locally

Requirements: JDK 17, Android SDK 35, and Gradle 8.9.

```bash
gradle test assembleDebug
```

APK output path:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Creator attribution

The app UI, launcher label, `CreatorBranding` object, ProGuard keep rule, and `NOTICE.md` identify **AxelzeroX23** as the creator. Release minification makes casual edits less straightforward, but no attribution can be made cryptographically unchangeable in a public source repository: anyone who can fork/edit source can modify it. Keep the repository ownership and commit history under your account, and do not commit signing keys or passwords.

## 1.5.1 development update

This revision adds the Image Optimizer, a JSON-only landscape stage editor, Psych→FNMM chart/asset export, image/audio/ZIP metadata attachments in Script Lab, more Sparrow frame reconstruction, character animation prefix inference, stage `addAnimationByPrefix` extraction, and Psych health icon splitting. It packages the user's `My-Mod` sample as the default Psych layout template. Thai and Japanese are selectable UI languages.

### Verification status

- ZIP input examples were inspected and source/template archives are structurally valid.
- The GIF LZW writer was checked with independent GIF decoding at small and larger image sizes.
- The Sprite Map sample contains 379 atlas rectangles, a 1034-frame timeline, 23 referenced animation-symbol names, and 285 distinct FF indices. FF references are mapped using the source atlas JSON array order; verify this against the original authoring tool/game before release.
- This container did not have Gradle or Android SDK platform tools, so this source ZIP has **not** been compiled into an APK here. GitHub Actions is configured to run `gradle test assembleDebug`; a green workflow is the first actual build verification.

The project deliberately reports unsupported conversions rather than claiming every engine mechanic has been ported. No static translator can guarantee arbitrary Haxe/Lua engine-state conversion without a runtime specification and per-mechanic reference fixtures.
