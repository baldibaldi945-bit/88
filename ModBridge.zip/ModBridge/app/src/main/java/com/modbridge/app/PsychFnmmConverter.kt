package com.modbridge.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt

/**
 * Best-effort Psych Engine -> Funky Maker Mobile exporter based on the supplied FNMM sample.
 * Charts are mapped to FNMM's two-by-four strumLines, atlases are cropped into numbered PNGs,
 * and simple makeLuaSprite stage assets are represented in scene.json. Unknown Lua/Haxe/event
 * behavior is retained as audit text and reported as unsupported, never silently claimed ported.
 */
internal object PsychFnmmConverter {
    data class Artifact(val name: String, val bytes: ByteArray, val song: String, val stage: String, val notes: Int)
    data class Result(val artifacts: List<Artifact>, val warnings: List<String>, val sourceFiles: Int)
    private data class Rect(val name: String, val x: Int, val y: Int, val w: Int, val h: Int, val rotated: Boolean, val frameX: Int, val frameY: Int, val frameW: Int, val frameH: Int)
    private data class StageObject(val alias: String, val asset: String, val x: Double, val y: Double, val scaleX: Double = 1.0, val scaleY: Double = 1.0, val fixed: Boolean = false)

    fun convert(input: ByteArray): Result {
        val sourceFiles = readZip(input)
        val files = stripRoot(sourceFiles)
        val chartFiles = files.filterKeys { path ->
            path.startsWith("data/", true) && path.endsWith(".json", true) &&
                !path.endsWith("/meta.json", true) && !path.endsWith("/events.json", true)
        }
        val warnings = mutableListOf<String>()
        if (chartFiles.isEmpty()) return Result(emptyList(), listOf("لم يتم العثور على شارتات Psych Engine داخل data/<song>/*.json."), files.size)
        val artifacts = mutableListOf<Artifact>()
        for ((chartPath, chartBytes) in chartFiles) {
            val root = runCatching { JSONObject(chartBytes.toString(Charsets.UTF_8).trimStart('\uFEFF')) }.getOrNull()
            if (root == null) {
                warnings += "شارت غير صالح وتم تخطيه: $chartPath"
                continue
            }
            val song = root.optJSONObject("song") ?: root
            val songName = safe(song.optString("song").ifBlank { chartPath.removePrefix("data/").substringBefore('/') })
            val stage = safe(song.optString("stage").ifBlank { "stage" })
            val localWarnings = mutableListOf<String>()
            val notes = convertNotes(song, localWarnings)
            val output = linkedMapOf<String, ByteArray>()
            output["data.json"] = notes.first.toString(2).toByteArray()
            output["events.json"] = JSONObject().put("events", JSONArray()).put("action_packs", JSONArray().put(JSONObject().put("actions", JSONArray()))).toString(2).toByteArray()
            output["scene.json"] = buildScene(files, song, stage, output, localWarnings).toString(2).toByteArray()
            copyAudio(files, songName, output, localWarnings)
            copySourceScripts(files, output)
            val roles = linkedMapOf("player" to song.optString("player1").ifBlank { "bf" }, "opponent" to song.optString("player2").ifBlank { "dad" }, "gf" to song.optString("gfVersion").ifBlank { "gf" })
            val stageJson = findStageJson(files, stage)
            roles.forEach { (role, charId) -> convertCharacter(files, charId, role, output, localWarnings) }
            val rawEvents = song.optJSONArray("events")
            if (rawEvents != null && rawEvents.length() > 0) {
                output["source-psych-events.json"] = rawEvents.toString(2).toByteArray()
                localWarnings += "${rawEvents.length()} أحداث Psych محفوظة في source-psych-events.json ولم تُحوّل إلى أحداث FNMM لأن أنواعها ليست مكافئة مثبتة في المثال."
            }
            val stageLua = findStageLua(files, stage)
            if (stageLua != null) {
                output["source_scripts/stages/$stage.lua.txt"] = files[stageLua]!!
                if (Regex("(runHaxeCode|runHaxeFunction|setProperty|callScript|addLuaScript|doTween|initLuaShader)", RegexOption.IGNORE_CASE).containsMatchIn(files[stageLua]!!.toString(Charsets.UTF_8))) {
                    localWarnings += "سكربت المرحلة يحتوي منطق Lua/Shader/خاص بالمحرك. تم حفظه كنص مرجعي ولم يُدّع تشغيله في FNMM."
                }
            }
            if (stageJson != null) output["source-stage.json"] = files[stageJson]!!
            output["conversion-report.txt"] = buildString {
                appendLine("ModBridge — Psych Engine to FNMM")
                appendLine("Song: $songName")
                appendLine("Stage: $stage")
                appendLine("Chart: $chartPath")
                appendLine("Notes converted: ${notes.second}")
                appendLine("Input files: ${files.size}")
                appendLine("Unsupported behavior is retained as source reference when practical; it is not executed by FNMM.")
                localWarnings.distinct().forEach { appendLine("- $it") }
            }.toByteArray()
            val zip = ByteArrayOutputStream()
            ZipOutputStream(zip).use { out -> output.forEach { (name, bytes) ->
                if (name.startsWith("/") || name.split('/').any { it == ".." || it == "." }) return@forEach
                out.putNextEntry(ZipEntry(name)); out.write(bytes); out.closeEntry()
            } }
            val chartBase = chartPath.substringAfterLast('/').substringBeforeLast('.')
            val difficulty = chartBase.removePrefix(songName).trim('-', '_', ' ').ifBlank {
                chartBase.takeIf { it != songName } ?: "normal"
            }
            val filename = "${songName}-${safe(difficulty)}-${stage}.FNMM"
            artifacts += Artifact(filename, zip.toByteArray(), songName, stage, notes.second)
            warnings += localWarnings
        }
        return Result(artifacts, warnings.distinct(), files.size)
    }

    private fun readZip(input: ByteArray): LinkedHashMap<String, ByteArray> {
        val files = linkedMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(input)).use { zin ->
            var total = 0L
            while (true) {
                val entry = zin.nextEntry ?: break
                val safePath = !entry.isDirectory && !entry.name.startsWith("/") && entry.name.split('/').none { it == ".." || it == "." }
                if (safePath) {
                    val out = ByteArrayOutputStream(); val buffer = ByteArray(32 * 1024); var size = 0L
                    while (true) {
                        val n = zin.read(buffer); if (n < 0) break
                        size += n; total += n
                        require(size <= 128L * 1024 * 1024 && total <= 512L * 1024 * 1024) { "حجم الملفات المفكوكة تجاوز الحد الآمن." }
                        out.write(buffer, 0, n)
                    }
                    files[entry.name] = out.toByteArray()
                }
                zin.closeEntry()
            }
        }
        return files
    }

    private fun stripRoot(input: Map<String, ByteArray>): LinkedHashMap<String, ByteArray> {
        val keys = input.keys
        val root = keys.firstOrNull()?.substringBefore('/', "") ?: ""
        return if (root.isNotBlank() && keys.all { it.startsWith("$root/") }) input.entries.associateTo(linkedMapOf()) { it.key.removePrefix("$root/") to it.value } else LinkedHashMap(input)
    }

    private fun convertNotes(song: JSONObject, warnings: MutableList<String>): Pair<JSONObject, Int> {
        val player = Array(4) { JSONArray() }
        val opponent = Array(4) { JSONArray() }
        val sections = song.optJSONArray("notes") ?: JSONArray()
        var count = 0
        for (si in 0 until sections.length()) {
            val section = sections.optJSONObject(si) ?: continue
            val mustHit = section.optBoolean("mustHitSection", false)
            val sectionNotes = section.optJSONArray("sectionNotes") ?: continue
            for (ni in 0 until sectionNotes.length()) {
                val row = sectionNotes.optJSONArray(ni) ?: continue
                if (row.length() < 2) continue
                val ms = row.optDouble(0, -1.0)
                val rawLane = row.optDouble(1, -1.0).roundToInt()
                val sustainMs = row.optDouble(2, 0.0)
                if (!ms.isFinite() || ms < 0 || rawLane < 0 || !sustainMs.isFinite()) continue
                if (rawLane > 7) {
                    if (warnings.none { it.startsWith("تم تجاهل نوتات بمسارات أكثر من 8") }) warnings += "تم تجاهل نوتات بمسارات أكثر من 8 لأن مخطط FNMM المرجعي يحتوي أربع مسارات لكل جهة."
                    continue
                }
                val lane = Math.floorMod(rawLane, 4)
                val isPlayer = if (rawLane > 3) !mustHit else mustHit
                val props = JSONObject().put("skin", 0.0).put("onMissEvent", -1.0).put("onPressEvent", -1.0)
                val type = row.optString(3).takeIf { it.isNotBlank() }
                if (type != null) props.put("sourcePsychNoteType", type)
                val note = JSONObject().put("props", props).put("duration", (sustainMs / 1000.0).coerceAtLeast(0.0)).put("start", ms / 1000.0)
                (if (isPlayer) player[lane] else opponent[lane]).put(note)
                count++
            }
            if (section.optBoolean("changeBPM", false)) warnings += "تغيير BPM داخل الشارت قرب القسم $si لم تتم مزامنته كحدث FNMM؛ قيمة BPM الأساسية محفوظة."
        }
        val lines = JSONArray()
        val playerLine = JSONArray(); player.forEach { playerLine.put(it) }; lines.put(playerLine)
        val opponentLine = JSONArray(); opponent.forEach { opponentLine.put(it) }; lines.put(opponentLine)
        val bpm = song.optDouble("bpm", 100.0).takeIf { it.isFinite() && it > 0 } ?: 100.0
        val types = linkedSetOf<String>()
        for (si in 0 until sections.length()) {
            val section = sections.optJSONObject(si) ?: continue
            val rows = section.optJSONArray("sectionNotes") ?: continue
            for (ni in 0 until rows.length()) {
                val row = rows.optJSONArray(ni) ?: continue
                if (row.length() > 3) row.optString(3).takeIf { it.isNotBlank() }?.let { types += it }
            }
        }
        if (types.isNotEmpty()) warnings += "أنواع النوت المخصصة (${types.joinToString()}) حُفظت في props.sourcePsychNoteType كمعلومة مصدر، لكنها تحتاج تعريفاً مكافئاً داخل FNMM لتعمل كميكانيك."
        val data = JSONObject().put("strumLines", lines).put("bpm", bpm).put("version", 2.0).put("npb", 12.0)
        return data to count
    }

    private fun buildScene(files: Map<String, ByteArray>, song: JSONObject, stage: String, output: MutableMap<String, ByteArray>, warnings: MutableList<String>): JSONObject {
        val stageJsonPath = findStageJson(files, stage)
        val stageInfo = stageJsonPath?.let { runCatching { JSONObject(files[it]!!.toString(Charsets.UTF_8).trimStart('\uFEFF')) }.getOrNull() }
        val objects = JSONArray()
        val stageObjects = extractStageObjects(files, stage, output, warnings)
        stageObjects.forEach { o ->
            objects.put(JSONObject().put("x", o.x).put("y", o.y).put("strumLine", -1.0).put("visible", true).put("spr", o.alias).put("fixed", o.fixed).put("scale", JSONObject().put("x", o.scaleX).put("y", o.scaleY)))
        }
        val opponentId = song.optString("player2").ifBlank { "dad" }
        val playerId = song.optString("player1").ifBlank { "bf" }
        val icons = JSONArray()
        // FNMM's scene icon order follows the reference: player first, opponent second.
        if (convertIcon(files, playerId, "icon-player", output)) icons.put("icon-player")
        else warnings += "أيقونة اللاعب $playerId غير موجودة؛ أضفها يدوياً إلى FNMM."
        if (convertIcon(files, opponentId, "icon-opponent", output)) icons.put("icon-opponent")
        else warnings += "أيقونة الخصم $opponentId غير موجودة؛ أضفها يدوياً إلى FNMM."
        val roles = listOf(
            Triple("gf", "gf", stageInfo?.optJSONArray("girlfriend")),
            Triple("opponent", opponentId, stageInfo?.optJSONArray("opponent")),
            Triple("player", playerId, stageInfo?.optJSONArray("boyfriend"))
        )
        roles.forEach { (alias, _, coords) ->
            val x = coords?.optDouble(0, if (alias == "player") 900.0 else 300.0) ?: if (alias == "player") 900.0 else 300.0
            val y = coords?.optDouble(1, 500.0) ?: 500.0
            objects.put(JSONObject().put("x", x).put("y", y).put("strumLine", when (alias) { "player" -> 0.0; "opponent" -> 1.0; else -> -1.0 }).put("visible", true).put("spr", alias).put("fixed", false).put("scale", JSONObject().put("x", 1.0).put("y", 1.0)))
        }
        val zoom = stageInfo?.optDouble("defaultZoom", 1.0)?.takeIf { it.isFinite() && it > 0 } ?: 1.0
        return JSONObject().put("objects", objects).put("icons", icons).put("cameras", JSONArray().put(JSONObject().put("x", 1080.0).put("y", 960.0).put("scale", zoom))).put("landscape", false)
    }

    private fun convertIcon(files: Map<String, ByteArray>, characterId: String, alias: String, output: MutableMap<String, ByteArray>): Boolean {
        val normalizedId = normalizeAssetId(characterId)
        val path = files.keys.firstOrNull { it.endsWith("/icons/icon-$characterId.png", true) || it.equals("images/icons/icon-$characterId.png", true) }
            ?: files.keys.firstOrNull { candidate ->
                candidate.substringAfterLast('/').removePrefix("icon-").removeSuffix(".png").let { normalizeAssetId(it) == normalizedId } && candidate.contains("/icons/", true)
            }
            ?: return false
        val bitmap = BitmapFactory.decodeByteArray(files[path]!!, 0, files[path]!!.size) ?: return false
        val frameW = (bitmap.width / 2).coerceAtLeast(1)
        val frameH = bitmap.height
        if (bitmap.width < 2 || frameW.toLong() * frameH > 8_000_000L) { bitmap.recycle(); return false }
        repeat(2) { index ->
            val crop = Bitmap.createBitmap(bitmap, (index * frameW).coerceAtMost(bitmap.width - 1), 0, frameW, frameH)
            output["sprites/$alias/$index.png"] = bitmapPng(crop)
            crop.recycle()
        }
        bitmap.recycle()
        val data = JSONArray()
        repeat(2) { data.put(JSONObject().put("spd", 1.0).put("num", "1").put("spd_fps", false).put("loop", true).put("scale", 1.0).put("offset", JSONObject().put("x", 0).put("y", 0)).put("bilinear", true)) }
        output["sprites/$alias/sprite.json"] = JSONObject().put("type", 3.0).put("data", data).toString(2).toByteArray()
        return true
    }

    private fun convertCharacter(files: Map<String, ByteArray>, characterId: String, alias: String, output: MutableMap<String, ByteArray>, warnings: MutableList<String>) {
        val normalizedId = normalizeAssetId(characterId)
        val charPath = files.keys.firstOrNull { it.equals("characters/$characterId.json", true) || it.endsWith("/characters/$characterId.json", true) }
            ?: files.keys.firstOrNull { path ->
                path.substringAfterLast('/').equals("${safe(characterId)}.json", true) ||
                    (path.contains("/characters/", true) && normalizeAssetId(path.substringAfterLast('/').removeSuffix(".json")) == normalizedId)
            }
        val charJson = charPath?.let { runCatching { JSONObject(files[it]!!.toString(Charsets.UTF_8).trimStart('\uFEFF')) }.getOrNull() }
        val imageBase = charJson?.optString("image")?.takeIf { it.isNotBlank() } ?: "characters/$characterId"
        val pngPath = findAsset(files, imageBase, "png")
        val xmlPath = findAsset(files, imageBase, "xml")
        val rects = xmlPath?.let { parseSparrow(files[it]!!) }.orEmpty()
        val atlasBytes = pngPath?.let { files[it] }
        val animationData = JSONArray()
        var writtenStrips = 0
        if (atlasBytes != null && rects.isNotEmpty()) {
            val atlas = BitmapFactory.decodeByteArray(atlasBytes, 0, atlasBytes.size, BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 })
            if (atlas != null && atlas.width.toLong() * atlas.height <= 40_000_000L) {
                val animations = charJson?.optJSONArray("animations") ?: JSONArray()
                fun addStrip(name: String, chosen: List<Rect>, fps: Double, loop: Boolean, offsetX: Double, offsetY: Double) {
                    val crops = chosen.mapNotNull { cropSparrowFrame(atlas, it) }
                    if (crops.isEmpty()) return
                    val strip = packHorizontalFrames(crops)
                    if (strip == null) {
                        crops.forEach { it.recycle() }
                        warnings += "تجاوز شريط الحركة $characterId/$name الحد الآمن للذاكرة؛ حُفظت الأصول الأصلية ولم يُنشأ الشريط."
                        return
                    }
                    val out = bitmapPng(strip)
                    strip.recycle()
                    crops.forEach { it.recycle() }
                    output["sprites/$alias/$writtenStrips.png"] = out
                    animationData.put(JSONObject()
                        .put("num", crops.size.toString())
                        .put("spd", fps.takeIf { it.isFinite() && it > 0 } ?: 24.0)
                        .put("spd_fps", true)
                        .put("loop", loop)
                        .put("scale", charJson?.optDouble("scale", 1.0) ?: 1.0)
                        .put("offset", JSONObject().put("x", offsetX).put("y", offsetY))
                        .put("bilinear", charJson?.optBoolean("no_antialiasing", false) != true))
                    writtenStrips++
                }
                for (ai in 0 until animations.length()) {
                    val anim = animations.optJSONObject(ai) ?: continue
                    val prefix = anim.optString("name").ifBlank { anim.optString("anim") }
                    if (prefix.isBlank()) continue
                    val byPrefix = rects.filter { it.name.startsWith(prefix, true) }.sortedBy { numericSuffix(it.name) }
                    val indices = anim.optJSONArray("indices")
                    val chosen = if (indices != null && indices.length() > 0) {
                        (0 until indices.length()).mapNotNull { position ->
                            val index = indices.optInt(position, -1)
                            byPrefix.getOrNull(index)
                                ?: rects.getOrNull(index)
                                ?: rects.firstOrNull { numericSuffix(it.name) == index }
                        }
                    } else byPrefix
                    if (chosen.isEmpty()) continue
                    val offset = anim.optJSONArray("offsets")
                    addStrip(prefix, chosen, anim.optDouble("fps", 24.0), anim.optBoolean("loop", false),
                        offset?.optDouble(0, 0.0) ?: 0.0, offset?.optDouble(1, 0.0) ?: 0.0)
                }
                if (animationData.length() == 0 && rects.isNotEmpty()) {
                    for ((inferredName, group) in inferAnimationGroups(rects)) {
                        addStrip(inferredName, group, 24.0, true, 0.0, 0.0)
                    }
                    if (animationData.length() > 0) warnings += "لم توجد مطابقة مباشرة لتعريفات حركة $characterId؛ استنتج ModBridge مجموعات الحركات من بادئات أسماء إطارات Sparrow. راجع ترتيبها قبل اللعب."
                }
                atlas.recycle()
            } else if (atlas != null) {
                atlas.recycle()
                warnings += "Atlas الشخصية $characterId تجاوز 40 ميغابكسل؛ تم الحفاظ على الملف وعدم تحميله إلى الذاكرة."
            }
        }
        if (writtenStrips == 0 && atlasBytes != null) {
            val bitmap = BitmapFactory.decodeByteArray(atlasBytes, 0, atlasBytes.size)
            if (bitmap != null) {
                output["sprites/$alias/0.png"] = bitmapPng(bitmap)
                bitmap.recycle()
                writtenStrips = 1
                animationData.put(JSONObject().put("num", "1").put("spd", 1.0).put("spd_fps", false).put("loop", true).put("scale", charJson?.optDouble("scale", 1.0) ?: 1.0).put("offset", JSONObject().put("x", 0).put("y", 0)).put("bilinear", true))
            }
            warnings += "الشخصية $characterId لم تتضمن مطابقة Sparrow Animation واضحة؛ تم حفظ الصورة كإطار ثابت."
        }
        if (writtenStrips == 0) warnings += "أصول الشخصية $characterId أو ملف PNG/XML غير موجودة؛ ستظهر الشخصية كمرجع مفقود في scene.json."
        val type = if (alias.equals("gf", true)) 0.0 else 1.0
        output["sprites/$alias/sprite.json"] = JSONObject().put("type", type).put("data", animationData).toString(2).toByteArray()
        if (charPath == null) warnings += "Character JSON غير موجود لـ $characterId؛ بُني Sprite Manifest أساسي اعتماداً على الأصول المتاحة."
    }

    private fun packHorizontalFrames(frames: List<Bitmap>): Bitmap? {
        if (frames.isEmpty()) return null
        val width = frames.sumOf { it.width.toLong() }
        val height = frames.maxOf { it.height }
        if (width <= 0 || width > 32768 || width * height > 24_000_000L) return null
        val strip = Bitmap.createBitmap(width.toInt(), height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(strip)
        var x = 0f
        frames.forEach { frame ->
            canvas.drawBitmap(frame, x, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            x += frame.width
        }
        return strip
    }

    private fun inferAnimationGroups(rects: List<Rect>): List<Pair<String, List<Rect>>> {
        val groups = linkedMapOf<String, MutableList<Rect>>()
        rects.forEach { rect ->
            val match = Regex("^(.*?)(\\d+)$").matchEntire(rect.name) ?: return@forEach
            val prefix = match.groupValues[1].trimEnd('_', '-', ' ')
            if (prefix.isNotBlank()) groups.getOrPut(prefix) { mutableListOf() }.add(rect)
        }
        val multiFrame = groups.filterValues { it.size >= 2 }.mapValues { (_, frames) -> frames.sortedBy { numericSuffix(it.name) } }
        return if (multiFrame.isNotEmpty()) multiFrame.toList() else if (rects.isNotEmpty()) listOf("default" to rects) else emptyList()
    }

    private fun extractStageObjects(files: Map<String, ByteArray>, stage: String, output: MutableMap<String, ByteArray>, warnings: MutableList<String>): List<StageObject> {
        val luaPath = findStageLua(files, stage) ?: return emptyList()
        val lua = files[luaPath]!!.toString(Charsets.UTF_8)
        val regex = Regex("(?:makeLuaSprite|makeAnimatedLuaSprite)\\s*\\(\\s*['\"]([^'\"]+)['\"]\\s*,\\s*['\"]([^'\"]+)['\"]\\s*(?:,\\s*(-?\\d+(?:\\.\\d+)?)\\s*,\\s*(-?\\d+(?:\\.\\d+)?))?", RegexOption.IGNORE_CASE)
        val result = mutableListOf<StageObject>()
        for (match in regex.findAll(lua)) {
            val originalAlias = match.groupValues[1]
            val alias = safe(originalAlias)
            val image = match.groupValues[2]
            val x = match.groupValues[3].toDoubleOrNull() ?: 0.0
            val y = match.groupValues[4].toDoubleOrNull() ?: 0.0
            val path = findImage(files, image)
            if (path == null) { warnings += "Stage sprite '$image' غير موجود داخل الأرشيف؛ تم تخطيه."; continue }
            val base = path.substringBeforeLast('.')
            val xml = findAsset(files, base, "xml")
            val bitmap = BitmapFactory.decodeByteArray(files[path]!!, 0, files[path]!!.size)
            if (bitmap == null) { warnings += "تعذر فك صورة المرحلة $image"; continue }
            var animationCount = 0
            val spriteAnimations = JSONArray()
            if (xml != null) {
                val rects = parseSparrow(files[xml]!!)
                val prefixCalls = Regex("addAnimationByPrefix\\s*\\(\\s*['\"]${Regex.escape(originalAlias)}['\"]\\s*,\\s*['\"]([^'\"]+)['\"]\\s*,\\s*['\"]([^'\"]+)['\"]\\s*,\\s*(\\d+)(?:\\s*,\\s*(true|false))?", RegexOption.IGNORE_CASE)
                for (call in prefixCalls.findAll(lua)) {
                    val animName = call.groupValues[1]
                    val prefix = call.groupValues[2]
                    val fps = call.groupValues[3].toDoubleOrNull() ?: 24.0
                    val loop = call.groupValues[4].equals("true", true)
                    val frames = rects.filter { it.name.startsWith(prefix, true) }.sortedBy { numericSuffix(it.name) }
                    val crops = frames.mapNotNull { cropSparrowFrame(bitmap, it) }
                    val strip = packHorizontalFrames(crops)
                    if (strip == null) {
                        crops.forEach { it.recycle() }
                        warnings += "شريط حركة المرحلة $alias/$animName تجاوز الحد الآمن أو لا يحتوي إطارات؛ تم تخطيه."
                        continue
                    }
                    output["sprites/$alias/$animationCount.png"] = bitmapPng(strip)
                    strip.recycle(); crops.forEach { it.recycle() }
                    spriteAnimations.put(JSONObject().put("spd", fps).put("num", crops.size.toString()).put("spd_fps", true).put("loop", loop).put("scale", 1.0).put("offset", JSONObject().put("x", 0).put("y", 0)).put("bilinear", true))
                    animationCount++
                }
                if (animationCount == 0 && rects.isNotEmpty()) {
                    val crops = rects.mapNotNull { cropSparrowFrame(bitmap, it) }
                    val strip = packHorizontalFrames(crops)
                    if (strip != null) {
                        output["sprites/$alias/0.png"] = bitmapPng(strip)
                        strip.recycle()
                        spriteAnimations.put(JSONObject().put("spd", 24.0).put("num", crops.size.toString()).put("spd_fps", true).put("loop", true).put("scale", 1.0).put("offset", JSONObject().put("x", 0).put("y", 0)).put("bilinear", true))
                        animationCount = 1
                    }
                    crops.forEach { it.recycle() }
                    warnings += "تم استخراج إطارات المرحلة $alias في شريط FNMM واحد؛ لم توجد addAnimationByPrefix متطابقة."
                }
            }
            val staticStageSprite = animationCount == 0
            if (staticStageSprite) {
                output["sprites/$alias/0.png"] = bitmapPng(bitmap)
                spriteAnimations.put(JSONObject().put("spd", 1.0).put("num", "1").put("spd_fps", false).put("loop", true).put("scale", 1.0).put("offset", JSONObject().put("x", bitmap.width / 2.0).put("y", bitmap.height / 2.0)).put("bilinear", true))
            }
            output["sprites/$alias/sprite.json"] = JSONObject().put("type", if (staticStageSprite) 2.0 else 1.0).put("data", spriteAnimations).toString(2).toByteArray()
            bitmap.recycle()
            val scaleCall = Regex("scaleObject\\s*\\(\\s*['\"]${Regex.escape(originalAlias)}['\"]\\s*,\\s*(-?\\d+(?:\\.\\d+)?)\\s*,\\s*(-?\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE).find(lua)
            val sx = scaleCall?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 1.0
            val sy = scaleCall?.groupValues?.getOrNull(2)?.toDoubleOrNull() ?: sx
            val scroll = Regex("setScrollFactor\\s*\\(\\s*['\"]${Regex.escape(originalAlias)}['\"]\\s*,\\s*(-?\\d+(?:\\.\\d+)?)\\s*,\\s*(-?\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE).find(lua)
            val fixed = scroll?.let { it.groupValues[1].toDoubleOrNull() == 0.0 && it.groupValues[2].toDoubleOrNull() == 0.0 } ?: false
            result += StageObject(alias, image, x, y, sx, sy, fixed)
        }
        if (result.isNotEmpty()) {
            val dynamic = Regex("(?:makeLuaSprite|makeAnimatedLuaSprite)\\s*\\(\\s*['\"]([^'\"]+)['\"]\\s*,\\s*['\"]([^'\"]+)['\"]\\s*,\\s*[^'\"]*[A-Za-z_]", RegexOption.IGNORE_CASE)
            if (dynamic.containsMatchIn(lua)) warnings += "بعض مواضع Stage Lua تعتمد على تعبيرات متغيرة ولم يمكن تحويلها كقيم رقمية ثابتة."
        }
        if (Regex("objectPlayAnimation|playAnim|addAnimationByIndices|doTween|runHaxeCode|initLuaShader", RegexOption.IGNORE_CASE).containsMatchIn(lua)) {
            warnings += "تم تحويل إطارات Sprite Map والحركات الثابتة القابلة للاستخراج؛ تسلسل أحداث Lua/Tween/Shader ما زال مرجعياً وليس مكافئاً تشغيلياً داخل FNMM."
        }
        return result
    }

    private fun cropSparrowFrame(atlas: Bitmap, rect: Rect): Bitmap? {
        if (rect.x < 0 || rect.y < 0 || rect.w <= 0 || rect.h <= 0 || rect.x + rect.w > atlas.width || rect.y + rect.h > atlas.height) return null
        var crop = Bitmap.createBitmap(atlas, rect.x, rect.y, rect.w, rect.h)
        if (rect.rotated) {
            val rotated = Bitmap.createBitmap(crop, 0, 0, crop.width, crop.height, Matrix().apply { postRotate(-90f) }, true)
            if (rotated !== crop) crop.recycle()
            crop = rotated
        }
        val canvasWidth = rect.frameW.takeIf { it > 0 } ?: crop.width
        val canvasHeight = rect.frameH.takeIf { it > 0 } ?: crop.height
        val boundedW = canvasWidth.coerceIn(1, 8192)
        val boundedH = canvasHeight.coerceIn(1, 8192)
        if (boundedW.toLong() * boundedH > 16_000_000L) return crop
        if (boundedW == crop.width && boundedH == crop.height && rect.frameX == 0 && rect.frameY == 0) return crop
        val result = Bitmap.createBitmap(boundedW, boundedH, Bitmap.Config.ARGB_8888)
        Canvas(result).drawBitmap(crop, -rect.frameX.toFloat(), -rect.frameY.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        crop.recycle()
        return result
    }

    private fun parseSparrow(bytes: ByteArray): List<Rect> {
        return runCatching {
            val parser = Xml.newPullParser()
            parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
            val list = mutableListOf<Rect>()
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name.equals("SubTexture", true)) {
                    fun attr(name: String, default: Int = 0) = parser.getAttributeValue(null, name)?.toIntOrNull() ?: default
                    list += Rect(parser.getAttributeValue(null, "name") ?: "", attr("x"), attr("y"), attr("width"), attr("height"), parser.getAttributeValue(null, "rotated") == "true", attr("frameX"), attr("frameY"), attr("frameWidth", attr("width")), attr("frameHeight", attr("height")))
                }
                event = parser.next()
            }
            list
        }.getOrDefault(emptyList())
    }

    private fun copyAudio(files: Map<String, ByteArray>, song: String, output: MutableMap<String, ByteArray>, warnings: MutableList<String>) {
        val inst = files.entries.firstOrNull { (path, _) -> path.contains("songs/$song/", true) && path.substringAfterLast('/').substringBeforeLast('.').equals("Inst", true) }
        val voices = files.entries.firstOrNull { (path, _) -> path.contains("songs/$song/", true) && path.substringAfterLast('/').substringBeforeLast('.').equals("Voices", true) }
        if (inst != null) output["music.ogg"] = inst.value else warnings += "الموسيقى Instrumental غير موجودة للأغنية $song؛ أضف music.ogg داخل FNMM." 
        if (voices != null) output["vocals.ogg"] = voices.value
    }

    private fun copySourceScripts(files: Map<String, ByteArray>, output: MutableMap<String, ByteArray>) {
        val extensions = setOf("lua", "hx", "hxc", "hscript", "js", "frag", "vert", "glsl")
        var copied = 0
        for ((path, bytes) in files) {
            val ext = path.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext !in extensions) continue
            if (path.startsWith("source_scripts/", true)) continue
            val safePath = path.split('/').filter { it.isNotBlank() && it != "." && it != ".." }.joinToString("/")
            if (safePath.isBlank()) continue
            output["source_scripts/$safePath"] = bytes
            copied++
        }
        if (copied > 0) output["source_scripts/README.txt"] = "Source scripts retained for manual porting only. These files are not executed by Funky Maker Mobile. ModBridge translates only recognized static stage patterns and does not claim general Haxe/Lua runtime equivalence.\n".toByteArray()
    }

    private fun findStageJson(files: Map<String, ByteArray>, stage: String) = files.keys.firstOrNull { it.equals("stages/$stage.json", true) || it.endsWith("/stages/$stage.json", true) }
    private fun findStageLua(files: Map<String, ByteArray>, stage: String) = files.keys.firstOrNull { it.equals("stages/$stage.lua", true) || it.endsWith("/stages/$stage.lua", true) }

    private fun findAsset(files: Map<String, ByteArray>, base: String, ext: String): String? {
        val clean = base.removePrefix("assets/").removePrefix("./").removeSuffix(".$ext")
        return files.keys.firstOrNull { it.equals("$clean.$ext", true) || it.endsWith("/$clean.$ext", true) || it.substringAfterLast('/').equals("${clean.substringAfterLast('/') }.$ext", true) }
    }

    private fun findImage(files: Map<String, ByteArray>, reference: String): String? {
        val clean = reference.removeSuffix(".png").removeSuffix(".jpg")
        return files.keys.firstOrNull { it.endsWith("$clean.png", true) || it.endsWith("$clean.jpg", true) || it.endsWith("$clean.webp", true) }
    }

    private fun bitmapPng(bitmap: Bitmap): ByteArray = ByteArrayOutputStream().also { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
    private fun numericSuffix(value: String): Int = Regex("(\\d+)$").find(value)?.groupValues?.get(1)?.toIntOrNull() ?: Int.MAX_VALUE
    private fun normalizeAssetId(value: String): String = value.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }
    private fun safe(value: String): String = value.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9_-]+"), "-").trim('-').take(70).ifBlank { "converted" }
}
