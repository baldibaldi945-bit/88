package com.modbridge.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** ZIP-preserving Psych stage JSON editor and chart-side flip utility. */
internal object PsychModEditor {
    data class StageFile(val path: String, val name: String, val json: String)
    data class Inspection(val stages: List<StageFile>, val charts: Int, val totalFiles: Int)
    data class Values(
        val defaultZoom: String,
        val cameraSpeed: String,
        val boyfriendX: String, val boyfriendY: String,
        val cameraBoyfriendX: String, val cameraBoyfriendY: String,
        val girlfriendX: String, val girlfriendY: String,
        val cameraGirlfriendX: String, val cameraGirlfriendY: String,
        val opponentX: String, val opponentY: String,
        val cameraOpponentX: String, val cameraOpponentY: String
    )
    data class SaveResult(val bytes: ByteArray, val changedCharts: Int, val changedStage: String)

    fun inspect(input: ByteArray): Inspection {
        val files = read(input)
        val stages = files.filterKeys { it.startsWith("stages/", true) && it.endsWith(".json", true) }
            .mapNotNull { (path, bytes) ->
                val json = runCatching { JSONObject(bytes.toString(Charsets.UTF_8).trimStart('\uFEFF')) }.getOrNull() ?: return@mapNotNull null
                StageFile(path, path.substringAfterLast('/').substringBeforeLast('.'), json.toString(2))
            }.sortedBy { it.name }
        val charts = files.count { (path, bytes) ->
            path.startsWith("data/", true) && path.endsWith(".json", true) &&
                runCatching { val root = JSONObject(bytes.toString(Charsets.UTF_8).trimStart('\uFEFF')); (root.optJSONObject("song") ?: root).has("notes") }.getOrDefault(false)
        }
        return Inspection(stages, charts, files.size)
    }

    fun defaults(stage: StageFile): Values {
        val j = JSONObject(stage.json)
        fun pair(key: String, index: Int): String = j.optJSONArray(key)?.optDouble(index, 0.0)?.toString() ?: "0"
        return Values(
            j.optDouble("defaultZoom", 0.9).toString(), j.optDouble("camera_speed", 1.0).toString(),
            pair("boyfriend", 0), pair("boyfriend", 1), pair("camera_boyfriend", 0), pair("camera_boyfriend", 1),
            pair("girlfriend", 0), pair("girlfriend", 1), pair("camera_girlfriend", 0), pair("camera_girlfriend", 1),
            pair("opponent", 0), pair("opponent", 1), pair("camera_opponent", 0), pair("camera_opponent", 1)
        )
    }

    fun save(input: ByteArray, stage: StageFile, values: Values, flipPlayerOpponent: Boolean): SaveResult {
        val files = read(input)
        val original = files[stage.path] ?: error("ملف المرحلة لم يعد موجوداً داخل الأرشيف.")
        val json = JSONObject(original.toString(Charsets.UTF_8).trimStart('\uFEFF'))
        fun number(key: String, value: String) {
            val parsed = value.toDoubleOrNull()?.takeIf { it.isFinite() } ?: error("قيمة $key ليست رقماً صالحاً.")
            json.put(key, parsed)
        }
        fun pair(key: String, x: String, y: String) {
            val px = x.toDoubleOrNull()?.takeIf { it.isFinite() } ?: error("إحداثي X غير صالح في $key.")
            val py = y.toDoubleOrNull()?.takeIf { it.isFinite() } ?: error("إحداثي Y غير صالح في $key.")
            json.put(key, JSONArray().put(px).put(py))
        }
        number("defaultZoom", values.defaultZoom)
        number("camera_speed", values.cameraSpeed)
        pair("boyfriend", values.boyfriendX, values.boyfriendY)
        pair("camera_boyfriend", values.cameraBoyfriendX, values.cameraBoyfriendY)
        pair("girlfriend", values.girlfriendX, values.girlfriendY)
        pair("camera_girlfriend", values.cameraGirlfriendX, values.cameraGirlfriendY)
        pair("opponent", values.opponentX, values.opponentY)
        pair("camera_opponent", values.cameraOpponentX, values.cameraOpponentY)
        files[stage.path] = json.toString(2).toByteArray()
        var changed = 0
        if (flipPlayerOpponent) {
            val chartPaths = files.keys.filter { it.startsWith("data/", true) && it.endsWith(".json", true) }
            chartPaths.forEach { path ->
                val chart = runCatching { JSONObject(files[path]!!.toString(Charsets.UTF_8).trimStart('\uFEFF')) }.getOrNull() ?: return@forEach
                val song = chart.optJSONObject("song") ?: chart
                val sections = song.optJSONArray("notes") ?: return@forEach
                var updated = false
                for (i in 0 until sections.length()) {
                    val section = sections.optJSONObject(i) ?: continue
                    section.put("mustHitSection", !section.optBoolean("mustHitSection", false))
                    updated = true
                }
                if (updated) {
                    if (chart.has("song")) chart.put("song", song)
                    files[path] = chart.toString(2).toByteArray()
                    changed++
                }
            }
        }
        return SaveResult(write(files), changed, stage.name)
    }

    private fun read(input: ByteArray): LinkedHashMap<String, ByteArray> {
        val result = linkedMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(input)).use { zip ->
            var total = 0L
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && !entry.name.startsWith("/") && entry.name.split('/').none { it == ".." || it == "." }) {
                    val out = ByteArrayOutputStream(); val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val n = zip.read(buffer); if (n < 0) break
                        total += n; require(total <= 512L * 1024 * 1024) { "حجم الأرشيف المفكوك تجاوز الحد الآمن." }
                        out.write(buffer, 0, n)
                    }
                    result[entry.name] = out.toByteArray()
                }
                zip.closeEntry()
            }
        }
        return result
    }

    private fun write(files: Map<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip -> files.forEach { (name, bytes) ->
            if (name.startsWith("/") || name.split('/').any { it == ".." || it == "." }) return@forEach
            zip.putNextEntry(ZipEntry(name)); zip.write(bytes); zip.closeEntry()
        } }
        return out.toByteArray()
    }
}
