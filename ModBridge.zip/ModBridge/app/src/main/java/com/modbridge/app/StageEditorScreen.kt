package com.modbridge.app

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private class Prepared(val gif: ByteArray?, val png: ByteArray?, val w: Int, val h: Int, val name: String)

private fun displayName(context: Context, uri: Uri): String = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }
}.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "file"

private fun readUri(context: Context, uri: Uri, limit: Int = 48 * 1024 * 1024): ByteArray {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("تعذرت قراءة الملف")
    require(bytes.size <= limit) { "الملف كبير جداً" }
    return bytes
}

private fun safeName(s: String): String = s.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "file" }

private fun prepareImage(context: Context, uri: Uri): Prepared {
    val name = displayName(context, uri)
    val bytes = readUri(context, uri)
    if (GifDecoder.isGif(bytes)) {
        val size = GifDecoder.size(bytes) ?: error("ملف GIF غير صالح")
        return Prepared(bytes, null, size.first, size.second, name)
    }
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0) error("صيغة الصورة غير مدعومة")
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 4096) sample *= 2
    val isPng = bytes.size > 8 && bytes[1] == 'P'.code.toByte() && bytes[2] == 'N'.code.toByte() && bytes[3] == 'G'.code.toByte()
    if (isPng && sample == 1) return Prepared(null, bytes, bounds.outWidth, bounds.outHeight, name)
    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        ?: error("تعذر فك الصورة")
    val out = java.io.ByteArrayOutputStream()
    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
    val w = bmp.width; val h = bmp.height
    bmp.recycle()
    return Prepared(null, out.toByteArray(), w * sample, h * sample, name)
}

private fun importSkin(context: Context, s: StageSession, uris: List<Uri>, folder: String): String {
    var png: Pair<String, ByteArray>? = null
    var xml: ByteArray? = null
    for (u in uris) {
        val n = displayName(context, u)
        if (n.endsWith(".png", true) && png == null) png = Pair(safeName(n), readUri(context, u))
        else if (n.endsWith(".xml", true) && xml == null) xml = readUri(context, u)
    }
    val p = png ?: error("اختر ملف PNG مع ملف XML الخاص به (Sparrow atlas).")
    val x = xml ?: error("ملف XML مفقود. السكن يحتاج PNG + XML معاً.")
    s.put("images/$folder/${p.first}.png", p.second)
    s.put("images/$folder/${p.first}.xml", x)
    return "$folder/${p.first}"
}

@Composable
private fun NumField(label: String, value: Float, modifier: Modifier, onValue: (Float) -> Unit) {
    var text by remember { mutableStateOf(fmtNum(value)) }
    LaunchedEffect(value) { if (text.toFloatOrNull() != value) text = fmtNum(value) }
    OutlinedTextField(
        value = text,
        onValueChange = { t -> text = t; t.toFloatOrNull()?.let { v -> if (v.isFinite()) onValue(v) } },
        label = { Text(label, fontSize = 11.sp) },
        singleLine = true,
        modifier = modifier
    )
}

@Composable
private fun TitleText(t: String) {
    Text(t, fontWeight = FontWeight.Bold, fontSize = 13.sp)
}

@Composable
private fun CharPicker(title: String, current: String, options: List<String>, onSet: (String) -> Unit) {
    var manual by remember { mutableStateOf("") }
    TitleText("$title: $current")
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { n -> FilterChip(selected = n == current, onClick = { onSet(n) }, label = { Text(n, fontSize = 11.sp) }) }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(manual, { manual = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("اسم شخصية يدوي", fontSize = 11.sp) })
        TextButton(onClick = { if (manual.isNotBlank()) { onSet(manual.trim()); manual = "" } }) { Text("تطبيق") }
    }
}

@Composable
internal fun StageEditorScreen() {
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    DisposableEffect(activity) {
        val previous = activity?.requestedOrientation
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        onDispose { if (previous != null) activity?.requestedOrientation = previous }
    }
    val scope = rememberCoroutineScope()
    val holder = remember { arrayOfNulls<StageSession>(1) }
    var session by remember { mutableStateOf<StageSession?>(null) }
    var stages by remember { mutableStateOf(emptyList<String>()) }
    var state by remember { mutableStateOf<StageState?>(null) }
    var characters by remember { mutableStateOf(emptyList<String>()) }
    var charts by remember { mutableStateOf(emptyList<ChartInfo>()) }
    var tick by remember { mutableStateOf(0) }
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("افتح مود Psych Engine بصيغة ZIP لبدء التعديل.") }
    var busy by remember { mutableStateOf(false) }
    var cameraFocus by remember { mutableStateOf(1) }
    var playing by remember { mutableStateOf(true) }
    var chartPath by remember { mutableStateOf("") }
    var flips by remember { mutableStateOf<Map<String, Set<Int>>>(emptyMap()) }
    var swapMode by remember { mutableStateOf(0) }
    var skinAll by remember { mutableStateOf(false) }
    var applyChars by remember { mutableStateOf(true) }
    var arrowLabel by remember { mutableStateOf("") }
    var splashLabel by remember { mutableStateOf("") }
    var hbStyle by remember { mutableStateOf(-1) }
    var customHb by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var replaceTarget by remember { mutableStateOf<StageObj?>(null) }
    var outFile by remember { mutableStateOf<File?>(null) }
    var shSel by remember { mutableStateOf(0) }
    var testMode by remember { mutableStateOf(0) }
    var testScene by remember { mutableStateOf<Bitmap?>(null) }
    val plan = remember { EditPlan() }
    val view = remember { StagePreviewView(context) }
    val hbFrames = remember { HealthBarStyles.names.indices.map { HealthBarStyles.render(it) } }
    val hbPreviews = remember { hbFrames.map { HealthBarStyles.preview(it, 0xFFFF0000.toInt(), 0xFF66FF33.toInt(), 0.5f).asImageBitmap() } }

    DisposableEffect(Unit) { onDispose { holder[0]?.close() } }

    fun touch() { tick++; view.invalidate() }

    fun openStage(name: String) {
        val s = session ?: return
        busy = true
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { StageState.load(s, name) } }
            r.onSuccess {
                state = it; selected = ""; view.clearCache(); view.fitView(); shSel = it.shaders.firstOrNull()?.id ?: 0; testMode = 0
                status = "المرحلة ${it.name}: ${it.objects.size} عنصر مقروء من Lua" +
                    (if (it.unparsedLuaCalls > 0) " • ${it.unparsedLuaCalls} استدعاء بقيم غير ثابتة لم يُقرأ" else "")
            }.onFailure { status = "تعذر فتح المرحلة: ${it.message}" }
            busy = false
        }
    }

    val modPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            view.session = null; view.state = null
            holder[0]?.close(); holder[0] = null; session = null; state = null
            busy = true; status = "جارٍ نسخ المود وفهرسته..."
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    runCatching {
                        val dir = File(context.cacheDir, "stage-edit"); dir.mkdirs()
                        dir.listFiles()?.forEach { it.delete() }
                        val f = File(dir, "source-${System.currentTimeMillis()}.zip")
                        context.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } } ?: error("تعذرت قراءة الملف")
                        val s = StageSession(f)
                        Triple(s, s.stageNames(), Pair(s.characterNames(), s.charts()))
                    }
                }
                r.onSuccess { (s, names, extra) ->
                    holder[0] = s; session = s; stages = names; characters = extra.first; charts = extra.second
                    flips = emptyMap(); chartPath = extra.second.firstOrNull()?.path.orEmpty()
                    status = "تم فتح المود: ${names.size} مرحلة • ${extra.first.size} شخصية • ${extra.second.size} شارت"
                    if (names.isNotEmpty()) { openStage(names[0]) } else { busy = false }
                }.onFailure { status = "تعذر فتح المود: ${it.message}"; busy = false }
                if (r.isFailure) busy = false
            }
        }
    }

    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val f = outFile
        if (uri != null && f != null) {
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { i -> i.copyTo(o) } } ?: error("تعذر فتح ملف الحفظ") }
                }
                status = if (r.isSuccess) "تم حفظ المود المعدل." else "تعذر الحفظ: ${r.exceptionOrNull()?.message}"
            }
        }
    }

    fun doSave() {
        val s = session; val st = state
        if (s == null || st == null) { status = "افتح مود أولاً."; return }
        busy = true; status = "جارٍ تجهيز المود المعدل..."
        plan.flips = flips; plan.swapMode = swapMode; plan.applyCharacters = applyChars; plan.skinsForAllCharts = skinAll
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val f = File(context.cacheDir, "stage-edit/out.zip")
                    val summary = StageSaver.save(s, st, plan, f)
                    Triple(f, summary, s.charts())
                }
            }
            r.onSuccess { (f, summary, newCharts) ->
                outFile = f; charts = newCharts; flips = emptyMap(); arrowLabel = ""; splashLabel = ""; hbStyle = -1; customHb = null
                view.clearCache(); touch()
                status = "جاهز: $summary"
                savePicker.launch("ModBridge-${st.name}-edited.zip")
            }.onFailure { status = "تعذر الحفظ: ${it.message}" }
            busy = false
        }
    }

    fun addPrepared(p: Prepared) {
        val st = state ?: return
        val s = session ?: return
        val n = st.nextId++
        val tag = "mb_$n"
        val o = StageObj("n_$tag", tag, if (p.gif != null) ObjKind.GIF else ObjKind.SPRITE, "", 640f - p.w / 2f, 360f - p.h / 2f)
        o.isNew = true; o.label = p.name
        if (p.gif != null) o.gifBytes = p.gif else { s.put("images/modbridge/$tag.png", p.png!!); o.image = "modbridge/$tag" }
        val old = replaceTarget
        if (old != null) {
            o.x = old.x; o.y = old.y; o.scrollX = old.scrollX; o.scrollY = old.scrollY; o.front = old.front
            if (old.isNew) st.objects.remove(old) else { old.removed = true; o.replaces = old.tag }
        }
        replaceTarget = null
        st.objects.add(o)
        selected = o.id
        touch()
        status = "تمت إضافة ${p.name}" + (if (p.gif != null) " (سيتحول GIF إلى سبرايت عند الحفظ)" else "")
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { prepareImage(context, uri) } }
                r.onSuccess { addPrepared(it) }.onFailure { status = "تعذر إضافة الصورة: ${it.message}" }
                busy = false
            }
        }
    }
    val arrowPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val s = session
        if (s != null && uris.isNotEmpty()) scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { importSkin(context, s, uris, "noteSkins") } }
            r.onSuccess { plan.arrowSkin = it; arrowLabel = it; status = "سكن الأسهم جاهز: $it" }.onFailure { status = it.message ?: "فشل" }
        }
    }
    val splashPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val s = session
        if (s != null && uris.isNotEmpty()) scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { importSkin(context, s, uris, "noteSplashes") } }
            r.onSuccess { plan.splashSkin = it; splashLabel = it; status = "سبلاش جاهز: $it" }.onFailure { status = it.message ?: "فشل" }
        }
    }
    val hbPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val st = state
        if (uri != null && st != null) scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val bytes = readUri(context, uri, 8 * 1024 * 1024)
                    val b = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("PNG غير صالح")
                    Pair(bytes, b)
                }
            }
            r.onSuccess { st.healthBarPng = it.first; hbStyle = 99; customHb = it.second.asImageBitmap(); status = "تم اختيار شكل هلث بار مخصص" }
                .onFailure { status = "تعذر قراءة الصورة: ${it.message}" }
        }
    }

    val t = tick // subscribe to model changes
    val st = state
    val sel: StageObj? = st?.objects?.firstOrNull { it.id == selected }

    Column(Modifier.fillMaxSize().padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { modPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }, enabled = !busy) { Text("📦 فتح مود", fontSize = 12.sp) }
            Button(onClick = { doSave() }, enabled = !busy && st != null) { Text("💾 حفظ ZIP", fontSize = 12.sp) }
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                stages.forEach { n -> FilterChip(selected = st?.name == n, onClick = { openStage(n) }, enabled = !busy, label = { Text(n, fontSize = 11.sp) }) }
            }
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.weight(0.56f).fillMaxHeight()) {
                AndroidView(factory = {
                    view.onPick = { key -> selected = key; tab = if (key == "bf" || key == "dad" || key == "gf" || key.startsWith("cam_")) 1 else 0 }
                    view.onEdited = { tick++ }
                    view
                }, modifier = Modifier.fillMaxSize(), update = { v ->
                    val tt = tick
                    v.session = session; v.state = state; v.selected = selected; v.cameraFocus = cameraFocus; v.playing = playing
                    v.invalidate()
                })
                if (testMode != 0 && st != null && session != null) {
                    val sess = session!!
                    AndroidView(factory = { ctx -> ShaderTestView(ctx).also { v -> v.onLog = { m -> status = m } } }, modifier = Modifier.fillMaxSize(), update = { v ->
                        val tt = tick
                        v.setScene(testScene)
                        v.setChain(ShaderLib.chain(st, sess, if (testMode == 2) st.shaders.firstOrNull { it.id == shSel } else null))
                    })
                }
                Row(Modifier.align(Alignment.TopStart).horizontalScroll(rememberScrollState()).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("بدون إطار", "إطار BF", "إطار Dad", "إطار GF").forEachIndexed { i, l ->
                        FilterChip(selected = cameraFocus == i, onClick = { cameraFocus = i }, label = { Text(l, fontSize = 10.sp) })
                    }
                    FilterChip(selected = playing, onClick = { playing = !playing }, label = { Text(if (playing) "⏸" else "▶", fontSize = 10.sp) })
                    FilterChip(selected = false, onClick = { view.fitView() }, label = { Text("⤢", fontSize = 10.sp) })
                }
            }
            Column(Modifier.weight(0.44f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("العناصر", "الشخصيات والكاميرا", "الشارت", "السكنات", "الشادرات").forEachIndexed { i, l ->
                        FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(l, fontSize = 11.sp) })
                    }
                }
                if (st == null) {
                    Text("لا توجد مرحلة مفتوحة. اسحب العناصر بإصبعك داخل المعاينة، واستخدم إصبعين للتكبير.", fontSize = 12.sp)
                } else when (tab) {
                    0 -> {
                        Button(onClick = { replaceTarget = null; imagePicker.launch(arrayOf("image/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("➕ إضافة صورة / GIF", fontSize = 12.sp) }
                        st.objects.forEach { o ->
                            Row(Modifier.fillMaxWidth().clickable { selected = o.id }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    (if (o.id == selected) "▶ " else "") + (if (o.removed) "✖ " else "") + (if (o.kind == ObjKind.SPRITE) "🖼 " else "🎞 ") + (o.label.ifEmpty { o.tag }) + (if (o.isNew) " (جديد)" else ""),
                                    fontSize = 12.sp, fontWeight = if (o.id == selected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                        if (st.objects.isEmpty()) Text("لم أجد عناصر مرحلة قابلة للقراءة في stages/${st.name}.lua. يمكنك إضافة عناصر جديدة بالزر أعلاه.", fontSize = 11.sp)
                        if (sel != null) {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    TitleText(sel.label.ifEmpty { sel.tag })
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        NumField("X", sel.x, Modifier.weight(1f)) { sel.x = it; touch() }
                                        NumField("Y", sel.y, Modifier.weight(1f)) { sel.y = it; touch() }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        NumField("Scale X", sel.scaleX, Modifier.weight(1f)) { sel.scaleX = it; touch() }
                                        NumField("Scale Y", sel.scaleY, Modifier.weight(1f)) { sel.scaleY = it; touch() }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        NumField("Scroll X", sel.scrollX, Modifier.weight(1f)) { sel.scrollX = it; touch() }
                                        NumField("Scroll Y", sel.scrollY, Modifier.weight(1f)) { sel.scrollY = it; touch() }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        NumField("Alpha", sel.alpha, Modifier.weight(1f)) { sel.alpha = it; touch() }
                                        NumField("Angle", sel.angle, Modifier.weight(1f)) { sel.angle = it; touch() }
                                    }
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        listOf(-10f, -1f, 1f, 10f).forEach { d ->
                                            OutlinedButton(onClick = { sel.x += d; touch() }) { Text("X${if (d > 0) "+" else ""}${fmtNum(d)}", fontSize = 10.sp) }
                                        }
                                    }
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        listOf(-10f, -1f, 1f, 10f).forEach { d ->
                                            OutlinedButton(onClick = { sel.y += d; touch() }) { Text("Y${if (d > 0) "+" else ""}${fmtNum(d)}", fontSize = 10.sp) }
                                        }
                                    }
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        FilterChip(selected = sel.flipX, onClick = { sel.flipX = !sel.flipX; touch() }, label = { Text("↔ قلب X", fontSize = 10.sp) })
                                        FilterChip(selected = sel.flipY, onClick = { sel.flipY = !sel.flipY; touch() }, label = { Text("↕ قلب Y", fontSize = 10.sp) })
                                        if (sel.isNew) {
                                            FilterChip(selected = sel.front, onClick = { sel.front = !sel.front; touch() }, label = { Text("أمام الشخصيات", fontSize = 10.sp) })
                                            FilterChip(selected = sel.sendToBack, onClick = { sel.sendToBack = !sel.sendToBack; touch() }, label = { Text("خلف كل شيء", fontSize = 10.sp) })
                                        }
                                    }
                                    if (sel.kind != ObjKind.SPRITE) NumField("FPS", sel.fps.toFloat(), Modifier.fillMaxWidth()) { sel.fps = it.toInt().coerceIn(1, 60); touch() }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        OutlinedButton(onClick = { replaceTarget = sel; imagePicker.launch(arrayOf("image/*")) }, enabled = !busy) { Text("🔄 استبدال", fontSize = 11.sp) }
                                        if (sel.removed) OutlinedButton(onClick = { sel.removed = false; touch() }) { Text("↩ استرجاع", fontSize = 11.sp) }
                                        else OutlinedButton(onClick = {
                                            if (sel.isNew) st.objects.remove(sel) else sel.removed = true
                                            selected = ""; touch()
                                        }) { Text("🗑 حذف", fontSize = 11.sp) }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            NumField("Default Zoom", st.defaultZoom, Modifier.weight(1f)) { st.defaultZoom = it; touch() }
                            NumField("Camera Speed", st.cameraSpeed, Modifier.weight(1f)) { st.cameraSpeed = it; touch() }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("إخفاء GF", fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Switch(checked = st.hideGf, onCheckedChange = { st.hideGf = it; touch() })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("تطبيق الشخصيات على شارتات هذه المرحلة عند الحفظ", fontSize = 11.sp, modifier = Modifier.weight(1f))
                            Switch(checked = applyChars, onCheckedChange = { applyChars = it })
                        }
                        Text("الدوائر الملونة في المعاينة = نقاط الكاميرا. اسحبها لتعديل camera_* مباشرة.", fontSize = 11.sp)
                        listOf(
                            Triple("BF", st.bfChar, Triple(st.bf, st.camBf, 0)),
                            Triple("Dad", st.dadChar, Triple(st.dad, st.camDad, 1)),
                            Triple("GF", st.gfChar, Triple(st.gf, st.camGf, 2))
                        ).forEach { (label, current, pts) ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    CharPicker(label, current, characters) { n ->
                                        when (pts.third) { 0 -> st.bfChar = n; 1 -> st.dadChar = n; else -> st.gfChar = n }
                                        view.clearCache(); touch()
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        NumField("$label X", pts.first.x, Modifier.weight(1f)) { pts.first.x = it; touch() }
                                        NumField("$label Y", pts.first.y, Modifier.weight(1f)) { pts.first.y = it; touch() }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        NumField("Cam X", pts.second.x, Modifier.weight(1f)) { pts.second.x = it; touch() }
                                        NumField("Cam Y", pts.second.y, Modifier.weight(1f)) { pts.second.y = it; touch() }
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        val ordered = charts.sortedByDescending { it.stage == st.name }
                        if (ordered.isEmpty()) Text("لا توجد شارتات data/*.json في هذا المود.", fontSize = 12.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ordered.forEach { c ->
                                FilterChip(selected = chartPath == c.path, onClick = { chartPath = c.path },
                                    label = { Text((if (c.stage == st.name) "★ " else "") + c.path.removePrefix("data/").removeSuffix(".json"), fontSize = 10.sp) })
                            }
                        }
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = swapMode == 0, onClick = { swapMode = 0 }, label = { Text("قلب كامل: الأدوار + الكاميرا", fontSize = 10.sp) })
                            FilterChip(selected = swapMode == 1, onClick = { swapMode = 1 }, label = { Text("قلب النوتات فقط", fontSize = 10.sp) })
                        }
                        val info = charts.firstOrNull { it.path == chartPath }
                        if (info != null) {
                            val set = flips[info.path] ?: emptySet()
                            Text("اضغط الصفحة لقلبها بين اللاعب والخصم. P = الكاميرا على اللاعب، O = على الخصم، ✓ = ستُقلب عند الحفظ.", fontSize = 11.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedButton(onClick = { flips = flips + (info.path to info.mustHit.indices.toSet()) }) { Text("كل الصفحات", fontSize = 10.sp) }
                                OutlinedButton(onClick = { flips = flips + (info.path to info.mustHit.indices.filter { it !in set }.toSet()) }) { Text("عكس التحديد", fontSize = 10.sp) }
                                OutlinedButton(onClick = { flips = flips - info.path }) { Text("مسح", fontSize = 10.sp) }
                            }
                            info.mustHit.indices.chunked(6).forEach { row ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    row.forEach { i ->
                                        val flipped = i in set
                                        val player = if (swapMode == 0) info.mustHit[i] != flipped else info.mustHit[i]
                                        FilterChip(selected = flipped, onClick = {
                                            val n = if (flipped) set - i else set + i
                                            flips = flips + (info.path to n)
                                        }, modifier = Modifier.weight(1f), label = { Text("${i + 1}${if (player) "P" else "O"}${if (flipped) "✓" else ""}", fontSize = 9.sp) })
                                    }
                                    repeat(6 - row.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                    4 -> {
                        val sess = session
                        if (sess != null) ShaderPanel(
                            st = st, session = sess, selId = shSel, onSel = { shSel = it }, testMode = testMode,
                            onTest = { m ->
                                if (m == -1) { testScene = view.snapshot(640, 360); status = "تم تحديث لقطة المرحلة." }
                                else {
                                    if (m != 0) testScene = view.snapshot(640, 360)
                                    testMode = m
                                }
                                touch()
                            },
                            busy = busy, onChange = { touch() }, onStatus = { status = it }
                        )
                    }
                    else -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("تطبيق السكنات على كل الشارتات (وليس شارتات المرحلة فقط)", fontSize = 11.sp, modifier = Modifier.weight(1f))
                            Switch(checked = skinAll, onCheckedChange = { skinAll = it })
                        }
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                TitleText("شكل الأسهم (Note skin)")
                                Text(if (arrowLabel.isEmpty()) "اختر PNG + XML معاً" else arrowLabel, fontSize = 11.sp)
                                OutlinedButton(onClick = { arrowPicker.launch(arrayOf("image/png", "text/xml", "application/xml", "*/*")) }, enabled = !busy) { Text("🎯 اختيار الأسهم", fontSize = 11.sp) }
                                TitleText("شكل السبلاش (Note splash)")
                                Text(if (splashLabel.isEmpty()) "اختر PNG + XML معاً" else splashLabel, fontSize = 11.sp)
                                OutlinedButton(onClick = { splashPicker.launch(arrayOf("image/png", "text/xml", "application/xml", "*/*")) }, enabled = !busy) { Text("✨ اختيار السبلاش", fontSize = 11.sp) }
                            }
                        }
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                TitleText("شكل الهلث بار")
                                HealthBarStyles.names.forEachIndexed { i, n ->
                                    Column(Modifier.fillMaxWidth().clickable { st.healthBarPng = HealthBarStyles.toPng(hbFrames[i]); hbStyle = i; customHb = null; touch() }) {
                                        Text((if (hbStyle == i) "● " else "○ ") + n, fontSize = 11.sp)
                                        Image(bitmap = hbPreviews[i], contentDescription = n, modifier = Modifier.fillMaxWidth().height(20.dp), contentScale = ContentScale.FillBounds)
                                    }
                                }
                                OutlinedButton(onClick = { hbPicker.launch(arrayOf("image/png")) }, enabled = !busy) { Text("🖼 هلث بار مخصص (PNG)", fontSize = 11.sp) }
                                customHb?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.fillMaxWidth().height(24.dp), contentScale = ContentScale.FillBounds) }
                                Text("يُكتب images/healthBar.png. اللعبة ترسم التعبئة داخل الصورة بهامش 4 بكسل، لذا الأشكال هنا مصممة لتبقى التعبئة داخل الإطار.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        Text(status, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, maxLines = 2)
    }
}
