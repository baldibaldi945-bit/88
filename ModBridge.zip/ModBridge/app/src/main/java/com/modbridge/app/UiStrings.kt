package com.modbridge.app

enum class AppLanguage(val title: String) {
    ALGERIAN_ARABIC("العربية الجزائرية"),
    ENGLISH("English"),
    PORTUGUESE("Português"),
    JAPANESE("日本語"),
    THAI("ไทย"),
    STANDARD_ARABIC("العربية الفصحى")
}

data class UiStrings(
    val subtitle: String,
    val home: String,
    val library: String,
    val settings: String,
    val about: String,
    val sourceEngine: String,
    val autoDetect: String,
    val codename: String,
    val vslice: String,
    val fnmm: String,
    val chooseArchive: String,
    val noArchive: String,
    val outputFolder: String,
    val chooseFolder: String,
    val noFolder: String,
    val options: String,
    val optimizeShaders: String,
    val sourceBackup: String,
    val start: String,
    val ready: String,
    val analysing: String,
    val converting: String,
    val report: String,
    val darkMode: String,
    val sound: String,
    val language: String,
    val noSaved: String,
    val export: String,
    val delete: String,
    val aboutText: String,
    val supports: String,
    val limitations: String,
    val aiNote: String,
    val social: String,
    val creator: String,
    val saved: String,
    val unsupported: String,
    val chooseFirst: String,
    val outputDone: String,
    val copyright: String,
    val sourceHint: String,
    val successSound: String
)

fun stringsFor(language: AppLanguage): UiStrings = when (language) {
    AppLanguage.ENGLISH -> UiStrings(
        "Offline mod conversion to Psych Engine", "Home", "Library", "Settings", "About",
        "Source engine", "Auto detect", "Codename Engine", "V-Slice", "Funky Maker Mobile",
        "Choose mod archive (ZIP / 7Z)", "No archive selected", "Output folder", "Choose folder",
        "No output folder selected", "Conversion options", "Keep referenced shaders and remove unused ones",
        "Include a backup of unsupported source files", "Convert to Psych Engine", "Choose an archive and output folder to begin.",
        "Inspecting archive and identifying source format…", "Converting charts, assets, events and supported scripts…",
        "Conversion report", "Black / white theme", "Button and background sounds", "Language", "No saved conversions yet.",
        "Export ZIP", "Delete", "ModBridge converts supported V-Slice, Codename Engine and Funky Maker Mobile mod archives into a Psych Engine ZIP.",
        "Supported: charts, selected character/stage data, known events, audio/assets, referenced shaders and selected HScript patterns.",
        "Not guaranteed: custom engine states, unknown Haxe logic, every event or shader, and all proprietary formats. Always test the result in your Psych Engine version.",
        "Offline script helper uses deterministic rules, not a large language model. Unknown code is reported, not guessed or executed.",
        "Creator links", "Created by", "Saved to your private app library.", "Unsupported or unrecognized mod format.",
        "Choose a mod archive and output folder first.", "Psych Engine ZIP saved successfully.", "© 2026 AxelzeroX23. All rights reserved.",
        "Choose the source engine, or let the local scanner detect it.", "Success sound"
    )
    AppLanguage.PORTUGUESE -> UiStrings(
        "Conversão de mods offline para Psych Engine", "Início", "Biblioteca", "Configurações", "Sobre",
        "Motor de origem", "Detecção automática", "Codename Engine", "V-Slice", "Funky Maker Mobile",
        "Selecionar arquivo do mod (ZIP / 7Z)", "Nenhum arquivo selecionado", "Pasta de saída", "Selecionar pasta",
        "Nenhuma pasta de saída selecionada", "Opções de conversão", "Manter shaders referenciados e remover os não utilizados",
        "Incluir cópia dos arquivos de origem não convertidos", "Converter para Psych Engine", "Selecione um arquivo e uma pasta para começar.",
        "Analisando o arquivo e identificando o formato…", "Convertendo charts, recursos, eventos e scripts compatíveis…",
        "Relatório de conversão", "Tema preto / branco", "Sons de botões e música", "Idioma", "Ainda não há conversões salvas.",
        "Exportar ZIP", "Excluir", "ModBridge converte arquivos de mods V-Slice, Codename Engine e Funky Maker Mobile para um ZIP do Psych Engine.",
        "Compatível: charts, alguns dados de personagens/cenários, eventos conhecidos, áudio/recursos, shaders referenciados e padrões HScript selecionados.",
        "Não garantido: estados personalizados do motor, lógica Haxe desconhecida, todos os eventos ou shaders e formatos proprietários. Teste sempre no seu Psych Engine.",
        "O assistente offline usa regras determinísticas, não um grande modelo de linguagem. Código desconhecido é relatado, não inventado nem executado.",
        "Links do criador", "Criado por", "Salvo na biblioteca privada do aplicativo.", "Formato de mod não reconhecido ou não suportado.",
        "Selecione primeiro o arquivo do mod e a pasta de saída.", "ZIP do Psych Engine salvo com sucesso.", "© 2026 AxelzeroX23. Todos os direitos reservados.",
        "Escolha o motor de origem ou use a detecção local.", "Som de sucesso"
    )
    AppLanguage.JAPANESE -> UiStrings(
        "Psych Engine 向けオフライン MOD 変換", "ホーム", "ライブラリ", "設定", "情報",
        "元のエンジン", "自動検出", "Codename Engine", "V-Slice", "Funky Maker Mobile",
        "MOD アーカイブを選択 (ZIP / 7Z)", "未選択", "出力フォルダー", "フォルダーを選択",
        "出力先未選択", "変換オプション", "参照されるシェーダーを保持", "未変換ファイルのバックアップを含める",
        "Psych Engine に変換", "アーカイブと出力先を選択してください。", "アーカイブを解析中…", "チャート・素材・イベント・対応スクリプトを変換中…",
        "変換レポート", "ダーク / ライト", "効果音と BGM", "言語", "保存済みの変換はありません。", "ZIP をエクスポート", "削除",
        "対応する V-Slice、Codename Engine、Funky Maker Mobile の MOD を Psych Engine 用 ZIP に変換します。",
        "対応: チャート、一部のキャラクター/ステージ、既知イベント、音声/画像、参照シェーダー、一部 HScript。",
        "未保証: 独自エンジン状態、未知の Haxe、すべてのイベント/シェーダー、独自形式。ゲーム内で確認してください。",
        "オフライン補助機能は決定的なルールとサンプル検索を使用し、大規模言語モデルではありません。",
        "作者リンク", "作者", "アプリ内ライブラリに保存しました。", "未対応または不明な MOD 形式です。",
        "最初に MOD と出力先を選択してください。", "Psych Engine ZIP を保存しました。", "© 2026 AxelzeroX23. All rights reserved.",
        "元のエンジンを選ぶか自動検出してください。", "成功音"
    )
    AppLanguage.THAI -> UiStrings(
        "แปลงม็อดเป็น Psych Engine แบบออฟไลน์", "หน้าหลัก", "คลัง", "การตั้งค่า", "เกี่ยวกับ",
        "เอนจินต้นทาง", "ตรวจหาอัตโนมัติ", "Codename Engine", "V-Slice", "Funky Maker Mobile",
        "เลือกไฟล์ม็อด (ZIP / 7Z)", "ยังไม่ได้เลือกไฟล์", "โฟลเดอร์ปลายทาง", "เลือกโฟลเดอร์",
        "ยังไม่ได้เลือกโฟลเดอร์", "ตัวเลือกการแปลง", "เก็บ shader ที่มีการอ้างอิง", "รวมไฟล์ต้นฉบับที่ยังแปลงไม่ได้",
        "แปลงเป็น Psych Engine", "เลือกไฟล์ม็อดและโฟลเดอร์ปลายทางก่อน", "กำลังตรวจสอบไฟล์…", "กำลังแปลง chart, assets, events และสคริปต์ที่รองรับ…",
        "รายงานการแปลง", "ธีมมืด / สว่าง", "เสียงปุ่มและเพลงพื้นหลัง", "ภาษา", "ยังไม่มีรายการที่บันทึก", "ส่งออก ZIP", "ลบ",
        "ModBridge แปลงม็อด V-Slice, Codename Engine และ Funky Maker Mobile ที่รองรับเป็น ZIP สำหรับ Psych Engine",
        "รองรับ: chart, ข้อมูลตัวละคร/ฉากบางส่วน, event ที่รู้จัก, เสียง/ภาพ, shader ที่อ้างอิง และ HScript บางรูปแบบ",
        "ไม่รับประกัน: สถานะเอนจินแบบกำหนดเอง, Haxe ที่ไม่รู้จัก, event/shader ทั้งหมด และรูปแบบเฉพาะ โปรดทดสอบในเกม",
        "ตัวช่วยออฟไลน์ใช้กฎและค้นหาตัวอย่าง ไม่ใช่โมเดลภาษาขนาดใหญ่ และจะไม่เดาโค้ดที่ไม่รู้จัก",
        "ลิงก์ผู้สร้าง", "สร้างโดย", "บันทึกไว้ในคลังส่วนตัวของแอปแล้ว", "ไม่รองรับหรือไม่รู้จักรูปแบบม็อดนี้",
        "โปรดเลือกไฟล์ม็อดและโฟลเดอร์ปลายทางก่อน", "บันทึก ZIP สำหรับ Psych Engine แล้ว", "© 2026 AxelzeroX23. สงวนลิขสิทธิ์",
        "เลือกเอนจินต้นทางหรือใช้การตรวจหาอัตโนมัติ", "เสียงเมื่อสำเร็จ"
    )
    AppLanguage.STANDARD_ARABIC -> UiStrings(
        "تحويل المودات دون إنترنت إلى Psych Engine", "الرئيسية", "المكتبة", "الإعدادات", "حول التطبيق",
        "محرك المصدر", "اكتشاف تلقائي", "Codename Engine", "V-Slice", "Funky Maker Mobile",
        "اختيار أرشيف المود (ZIP / 7Z)", "لم يتم اختيار أرشيف", "مجلد الإخراج", "اختيار مجلد",
        "لم يتم اختيار مجلد إخراج", "خيارات التحويل", "الإبقاء على الشيدرات المشار إليها وحذف غير المستخدم منها",
        "إرفاق نسخة احتياطية من ملفات المصدر غير المحولة", "التحويل إلى Psych Engine", "اختر أرشيفاً ومجلد إخراج للبدء.",
        "جارٍ فحص الأرشيف وتحديد صيغة المصدر…", "جارٍ تحويل الشارتات والأصول والأحداث والسكربتات المدعومة…",
        "تقرير التحويل", "مظهر الأبيض والأسود", "أصوات الأزرار والموسيقى", "اللغة", "لا توجد تحويلات محفوظة بعد.",
        "تصدير ZIP", "حذف", "يحوّل ModBridge أرشيفات V-Slice وCodename Engine وFunky Maker Mobile المدعومة إلى ملف ZIP لمحرك Psych Engine.",
        "المدعوم: الشارتات، وبعض بيانات الشخصيات والمراحل، والأحداث المعروفة، والأصوات والأصول، والشيدرات المشار إليها وأنماط HScript محددة.",
        "غير مضمون: حالات المحرك المخصصة، ومنطق Haxe غير المعروف، وجميع الأحداث أو الشيدرات، والصيغ الاحتكارية. اختبر النتيجة دائماً في إصدار Psych Engine لديك.",
        "مساعد السكربتات دون إنترنت يعتمد قواعد محددة، وليس نموذجاً لغوياً ضخماً. يُذكر الكود غير المعروف في التقرير ولا يتم تخمينه أو تنفيذه.",
        "روابط المطور", "تطوير", "حُفظ في مكتبة التطبيق الخاصة.", "صيغة المود غير مدعومة أو غير معروفة.",
        "اختر أرشيف المود ومجلد الإخراج أولاً.", "تم حفظ ملف Psych Engine ZIP بنجاح.", "© 2026 AxelzeroX23. جميع الحقوق محفوظة.",
        "اختر محرك المصدر أو اترك الفاحص المحلي يحدده تلقائياً.", "صوت النجاح"
    )
    AppLanguage.ALGERIAN_ARABIC -> UiStrings(
        "حوّل المودات لـ Psych Engine بلا إنترنت", "الرئيسية", "المحفوظات", "الإعدادات", "معلومات التطبيق",
        "محرك المود الأصلي", "خليه يكتشف وحدو", "Codename Engine", "V-Slice", "Funky Maker Mobile",
        "اختار ملف المود (ZIP / 7Z)", "ما اخترتش ملف حتى الآن", "وين تحفظ النتيجة", "اختار مجلد",
        "ما اخترتش مجلد الحفظ", "خيارات التحويل", "خلي الشيدرات المستعملة ونحّي غير المستعملة",
        "دير نسخة احتياطية من ملفات المصدر اللي ما تحوّلتش", "حوّل لـ Psych Engine", "اختار ملف المود ومجلد الحفظ باش تبدا.",
        "راني نفحص الأرشيف ونتعرّف على نوع المحرك…", "راني نحوّل الشارتات والملفات والأحداث والسكربتات اللي نعرفها…",
        "تقرير التحويل", "الوضع الأسود والأبيض", "أصوات الأزرار والموسيقى", "اللغة", "مازال ما حفظت حتى تحويل.",
        "صدّر ZIP", "امسح", "ModBridge يحوّل مودات V-Slice وCodename Engine وFunky Maker Mobile المدعومة إلى ZIP تاع Psych Engine.",
        "يدعم: الشارتات، جزء من بيانات الشخصيات والستاجات، الأحداث المعروفة، الأصوات والصور، الشيدرات المستعملة وأنماط HScript محدودة.",
        "ما نضمنوش: الحالات المخصصة للمحرك، أكواد Haxe المجهولة، كل الأحداث أو الشيدرات، والصيغ المغلقة. جرّب النتيجة في نسخة Psych Engine اللي عندك.",
        "مساعد السكربتات يخدم بقواعد محلية، ماشي نموذج AI كبير. الكود اللي ما يفهموش يكتبو في التقرير وما يخترعوش وما ينفذوش.",
        "روابط صاحب التطبيق", "صنعه", "تحفظ في مكتبة التطبيق الخاصة بيك.", "نوع المود ما هوش مدعوم أو ما قدرش يتعرّف عليه.",
        "اختار ملف المود ومجلد الحفظ قبل.", "تحفظ ملف Psych Engine ZIP بنجاح.", "© 2026 AxelzeroX23. كل الحقوق محفوظة.",
        "اختار المحرك الأصلي ولا خليه الفاحص يتعرّف عليه وحدو.", "صوت النجاح"
    )
}
