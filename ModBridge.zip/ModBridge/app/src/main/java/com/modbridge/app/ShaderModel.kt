package com.modbridge.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.PI

/** Extra slider that belongs to one built-in shader (becomes a `uniform float`). */
internal class ShaderParam(val id: String, val label: String, val min: Float, val max: Float, val def: Float)

/** Built-in shader: common controls (strength, stability, place, size, weight, angle, shape) + its own extras. */
internal class ShaderPreset(
    val key: String,
    val title: String,
    val strength: Float, val stability: Float, val weight: Float, val size: Float, val shape: Int, val angle: Float,
    val params: List<ShaderParam>,
    val effect: String
)

/** One shader added by the user to the current stage. Saved inside the mod when it exists at save time. */
internal class ShaderInst(val id: Int, val key: String, var title: String) {
    var imported = false
    var fileName = ""          // imported: shaders/<fileName>.frag
    var ownsFile = false       // the .frag was added by this editor (deleted again if the shader is removed)
    var enabled = true
    var camera = 0             // 0 = camGame, 1 = camHUD, 2 = both
    var strength = 1f
    var stability = 1f         // 1 = perfectly still, 0 = pulsing / moving
    var cx = 0.5f
    var cy = 0.5f
    var size = 0.6f
    var weight = 1f            // light (<1) .. heavy (>1)
    var angle = 0f             // degrees
    var shape = 0              // 0 full, 1 circle, 2 box, 3 diamond, 4 band
    val extras = LinkedHashMap<String, Float>()
    var timeUniform = ""       // imported shaders: name of the time uniform to feed, if any

    val tag: String get() = "mbSh$id"
    val shaderName: String get() = if (imported) fileName else "MB_$key"
}

internal class TestPass(
    val source: String,
    val floats: Map<String, Float>,
    val vec2s: Map<String, Pair<Float, Float>>,
    val timeNames: List<String>
)

internal object ShaderLib {
    val shapeNames = listOf("كامل الشاشة", "دائرة", "مربع", "معيّن", "شريط")
    val cameraNames = listOf("كاميرا اللعبة", "الواجهة HUD", "الاثنتان")
    private val timeNames = listOf("iTime", "uTime", "time", "u_time", "iGlobalTime")
    private val reserved = setOf("bitmap", "openfl_TextureSize") + timeNames

    private const val HEADER = """#pragma header
uniform float iTime;
uniform float uStrength;
uniform float uStability;
uniform vec2 uCenter;
uniform float uSize;
uniform float uWeight;
uniform float uAngle;
uniform float uShape;
"""

    private const val COMMON = """
vec4 T(vec2 p){ return flixel_texture2D(bitmap, p); }
float mbAsp(){ return openfl_TextureSize.x / max(openfl_TextureSize.y, 1.0); }
float mbAmount(){ return uStrength * (1.0 + (1.0 - uStability) * 0.5 * sin(iTime * 4.0)); }
float mbMask(vec2 uv){
    if (uShape < 0.5) return 1.0;
    vec2 p = uv - uCenter; p.x *= mbAsp();
    float s = max(uSize, 0.01);
    float d;
    if (uShape < 1.5) d = length(p) / s;
    else if (uShape < 2.5) d = max(abs(p.x), abs(p.y)) / s;
    else if (uShape < 3.5) d = (abs(p.x) + abs(p.y)) / s;
    else d = abs(dot(p, vec2(-sin(uAngle), cos(uAngle)))) / s;
    return 1.0 - smoothstep(0.75, 1.0, d);
}
"""

    private const val MAIN = """
void main(){
    vec2 uv = openfl_TextureCoordv;
    vec4 base = T(uv);
    vec4 fx = mbEffect(uv, base);
    gl_FragColor = mix(base, fx, clamp(mbMask(uv), 0.0, 1.0));
}
"""

    val presets: List<ShaderPreset> = listOf(
        ShaderPreset("chroma", "انفصال ألوان (Chromatic)", 1f, 1f, 1f, 0.6f, 0, 0f, emptyList(), """
vec4 mbEffect(vec2 uv, vec4 base){
    vec2 d = vec2(cos(uAngle), sin(uAngle)) * 0.006 * uWeight * mbAmount();
    return vec4(T(uv + d).r, base.g, T(uv - d).b, base.a);
}"""),
        ShaderPreset("vignette", "فينيت (تغميق الأطراف)", 1f, 1f, 1f, 0.6f, 0, 0f, emptyList(), """
vec4 mbEffect(vec2 uv, vec4 base){
    vec2 p = uv - uCenter; p.x *= mbAsp();
    float k = clamp(length(p) * uWeight * 1.1, 0.0, 1.0); k = k * k;
    return vec4(base.rgb * (1.0 - clamp(k * mbAmount(), 0.0, 1.0)), base.a);
}"""),
        ShaderPreset("blur", "بلور اتجاهي", 1f, 1f, 1f, 0.6f, 0, 0f, emptyList(), """
vec4 mbEffect(vec2 uv, vec4 base){
    vec2 dir = vec2(cos(uAngle), sin(uAngle)) / openfl_TextureSize * uWeight * 2.0 * mbAmount();
    vec4 acc = vec4(0.0); float ws = 0.0;
    for (int i = -4; i <= 4; i++) {
        float w = exp(-float(i * i) / 8.0);
        acc += T(uv + dir * float(i)) * w; ws += w;
    }
    return acc / ws;
}"""),
        ShaderPreset("pixel", "بكسلة (Pixelate)", 1f, 1f, 1f, 0.6f, 0, 0f, emptyList(), """
vec4 mbEffect(vec2 uv, vec4 base){
    float px = max(1.0, floor(1.0 + uWeight * mbAmount() * 8.0));
    vec2 g = openfl_TextureSize / px;
    return T(floor(uv * g) / g + 0.5 / g);
}"""),
        ShaderPreset("scan", "خطوط مسح (Scanlines)", 1f, 1f, 1f, 0.6f, 0, 0f, emptyList(), """
vec4 mbEffect(vec2 uv, vec4 base){
    float l = dot(uv * openfl_TextureSize, vec2(-sin(uAngle), cos(uAngle)));
    float s = 0.5 + 0.5 * sin(l * 6.2832 / (2.0 + uWeight * 2.0) + iTime * (1.0 - uStability) * 6.0);
    return vec4(base.rgb * clamp(1.0 - 0.6 * mbAmount() * s, 0.0, 1.0), base.a);
}"""),
        ShaderPreset("wave", "تموّج (Wave)", 1f, 0.3f, 1f, 0.6f, 0, 0f, emptyList(), """
vec4 mbEffect(vec2 uv, vec4 base){
    vec2 dir = vec2(cos(uAngle), sin(uAngle));
    vec2 nrm = vec2(-dir.y, dir.x);
    float ph = dot(uv, nrm) * 25.0 + iTime * (1.0 - uStability) * 5.0;
    return T(uv + dir * sin(ph) * 0.008 * uWeight * mbAmount());
}"""),
        ShaderPreset("glow", "توهّج (Bloom)", 1f, 1f, 1f, 0.6f, 0, 0f, emptyList(), """
vec4 mbEffect(vec2 uv, vec4 base){
    vec3 sum = vec3(0.0);
    for (int i = 0; i < 8; i++) {
        float a = float(i) * 0.785398;
        vec2 o = vec2(cos(a), sin(a)) * 0.004 * uWeight;
        sum += T(uv + o).rgb + T(uv + o * 2.0).rgb;
    }
    sum /= 16.0;
    return vec4(base.rgb + sum * mbAmount() * 0.8, base.a);
}"""),
        ShaderPreset("tint", "تلوين / تحويل رمادي", 1f, 1f, 1f, 0.6f, 0, 0f, listOf(
            ShaderParam("uR", "أحمر", 0f, 2f, 1f), ShaderParam("uG", "أخضر", 0f, 2f, 0.6f),
            ShaderParam("uB", "أزرق", 0f, 2f, 0.4f), ShaderParam("uGray", "رمادي", 0f, 1f, 0f)
        ), """
uniform float uR; uniform float uG; uniform float uB; uniform float uGray;
vec4 mbEffect(vec2 uv, vec4 base){
    float g = dot(base.rgb, vec3(0.299, 0.587, 0.114));
    vec3 c = mix(base.rgb, vec3(g), uGray);
    c *= mix(vec3(1.0), vec3(uR, uG, uB), clamp(mbAmount(), 0.0, 1.0));
    c *= 0.75 + 0.25 * uWeight;
    return vec4(c, base.a);
}"""),
        ShaderPreset("glitch", "جلتش (Glitch)", 1f, 0.5f, 1f, 0.6f, 0, 0f, emptyList(), """
vec4 mbEffect(vec2 uv, vec4 base){
    float blk = floor(uv.y * (10.0 + uWeight * 20.0));
    float n = fract(sin(blk * 91.7 + floor(iTime * (1.0 - uStability) * 10.0) * 13.3) * 43758.5);
    float shift = step(0.8, n) * (n - 0.8) * 0.25 * mbAmount();
    vec2 d = vec2(cos(uAngle), sin(uAngle)) * shift;
    return vec4(T(uv + d).r, T(uv).g, T(uv - d).b, base.a);
}""")
    )

    fun preset(key: String): ShaderPreset? = presets.firstOrNull { it.key == key }

    /** Full GLSL source of a built-in preset (what gets written to shaders/MB_<key>.frag). */
    fun presetSource(p: ShaderPreset): String {
        val extras = if (p.params.isEmpty()) "" else "\n"
        return HEADER + COMMON + extras + p.effect + "\n" + MAIN
    }

    fun create(st: StageState, key: String): ShaderInst? {
        val p = preset(key) ?: return null
        val s = ShaderInst(st.nextShaderId++, key, p.title)
        applyDefaults(s, p)
        return s
    }

    fun applyDefaults(s: ShaderInst, p: ShaderPreset) {
        s.strength = p.strength; s.stability = p.stability; s.weight = p.weight; s.size = p.size
        s.shape = p.shape; s.angle = p.angle; s.cx = 0.5f; s.cy = 0.5f
        s.extras.clear(); p.params.forEach { s.extras[it.id] = it.def }
    }

    fun duplicate(st: StageState, o: ShaderInst): ShaderInst {
        val n = ShaderInst(st.nextShaderId++, o.key, o.title)
        n.imported = o.imported; n.fileName = o.fileName; n.ownsFile = o.ownsFile; n.enabled = o.enabled; n.camera = o.camera
        n.strength = o.strength; n.stability = o.stability; n.cx = o.cx; n.cy = o.cy; n.size = o.size
        n.weight = o.weight; n.angle = o.angle; n.shape = o.shape; n.timeUniform = o.timeUniform
        n.extras.putAll(o.extras)
        return n
    }

    /** GLSL source for a shader instance, or null if the file is missing from the mod. */
    fun source(s: ShaderInst, session: StageSession): String? =
        if (s.imported) session.readText("shaders/${s.fileName}.frag")
        else preset(s.key)?.let { presetSource(it) }

    /** Removes an instance; an imported .frag that this editor added is deleted too when nothing else uses it. */
    fun remove(st: StageState, session: StageSession, s: ShaderInst) {
        st.shaders.remove(s)
        if (s.imported && s.ownsFile && st.shaders.none { it.imported && it.fileName == s.fileName }) session.remove("shaders/${s.fileName}.frag")
    }

    // ---------- importing external shaders ----------

    class Imported(val inst: ShaderInst, val warning: String?)

    /** Registers an external .frag file in the mod and creates an instance whose float uniforms become controls. */
    fun importSource(st: StageState, session: StageSession, rawName: String, text: String): Imported {
        require(text.contains("void main")) { "الملف لا يحتوي على void main — ليس شادر فراجمنت صالحاً." }
        var base = rawName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "shader" }.take(48)
        var name = base; var n = 2
        while (session.exists("shaders/$name.frag") && session.readText("shaders/$name.frag") != text) { name = "${base}_$n"; n++ }
        val existed = session.exists("shaders/$name.frag")
        session.put("shaders/$name.frag", text.toByteArray(Charsets.UTF_8))
        val inst = ShaderInst(st.nextShaderId++, "file", name)
        inst.imported = true; inst.fileName = name; inst.ownsFile = !existed
        val uniforms = parseUniforms(text)
        for ((type, id) in uniforms) {
            if (id in timeNames && inst.timeUniform.isEmpty()) inst.timeUniform = id
            else if (type == "float" && id !in reserved) inst.extras[id] = 0.5f
        }
        val warn = when {
            Regex("(?m)^\\s*#version\\s+(3\\d\\d|4\\d\\d)").containsMatchIn(text) -> "يحتوي #version عالي (330+). Psych Engine يحتاج GLSL ES 1.00 وقد يفشل."
            !text.contains("#pragma header") -> "لا يحتوي #pragma header — سيُضاف تلقائياً في المعاينة فقط. تأكد أنه يعمل في اللعبة."
            else -> null
        }
        return Imported(inst, warn)
    }

    fun parseUniforms(src: String): List<Pair<String, String>> =
        Regex("uniform\\s+(?:lowp\\s+|mediump\\s+|highp\\s+)?(float|int|bool|vec2|vec3|vec4|sampler2D)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*;")
            .findAll(src).map { it.groupValues[1] to it.groupValues[2] }.toList()

    // ---------- live test chain (same GLSL that runs in game) ----------

    fun chain(st: StageState, session: StageSession, only: ShaderInst?): List<TestPass> {
        val out = ArrayList<TestPass>()
        for (s in st.shaders) {
            if (!s.enabled) continue
            if (only != null && s !== only) continue
            val src = source(s, session) ?: continue
            val f = LinkedHashMap<String, Float>()
            val v = LinkedHashMap<String, Pair<Float, Float>>()
            if (!s.imported) {
                f["uStrength"] = s.strength; f["uStability"] = s.stability; f["uSize"] = s.size
                f["uWeight"] = s.weight; f["uAngle"] = (s.angle * PI / 180.0).toFloat(); f["uShape"] = s.shape.toFloat()
                v["uCenter"] = s.cx to s.cy
            }
            f.putAll(s.extras)
            out.add(TestPass(src, f, v, if (s.timeUniform.isNotEmpty()) listOf("iTime", s.timeUniform) else listOf("iTime")))
        }
        return out
    }

    // ---------- persistence inside scripts/ModBridge_<stage>.lua ----------

    fun toJson(list: List<ShaderInst>): JSONArray {
        val a = JSONArray()
        for (s in list) {
            val j = JSONObject()
            j.put("id", s.id); j.put("key", s.key); j.put("title", s.title); j.put("imported", s.imported)
            j.put("file", s.fileName); j.put("own", s.ownsFile); j.put("on", s.enabled); j.put("cam", s.camera)
            j.put("str", s.strength.toString().toDouble()); j.put("stab", s.stability.toString().toDouble())
            j.put("cx", s.cx.toString().toDouble()); j.put("cy", s.cy.toString().toDouble())
            j.put("size", s.size.toString().toDouble()); j.put("w", s.weight.toString().toDouble())
            j.put("ang", s.angle.toString().toDouble()); j.put("shape", s.shape); j.put("time", s.timeUniform)
            val e = JSONObject(); s.extras.forEach { (k, v) -> e.put(k, v.toString().toDouble()) }
            j.put("extras", e)
            a.put(j)
        }
        return a
    }

    fun fromJson(arr: JSONArray?, st: StageState) {
        if (arr == null) return
        for (i in 0 until arr.length()) {
            val j = arr.optJSONObject(i) ?: continue
            val s = ShaderInst(j.optInt("id", st.nextShaderId), j.optString("key", "file"), j.optString("title", "shader"))
            s.imported = j.optBoolean("imported", false); s.fileName = j.optString("file", ""); s.ownsFile = j.optBoolean("own", false)
            s.enabled = j.optBoolean("on", true); s.camera = j.optInt("cam", 0).coerceIn(0, 2)
            s.strength = j.optDouble("str", 1.0).toFloat(); s.stability = j.optDouble("stab", 1.0).toFloat()
            s.cx = j.optDouble("cx", 0.5).toFloat(); s.cy = j.optDouble("cy", 0.5).toFloat()
            s.size = j.optDouble("size", 0.6).toFloat(); s.weight = j.optDouble("w", 1.0).toFloat()
            s.angle = j.optDouble("ang", 0.0).toFloat(); s.shape = j.optInt("shape", 0).coerceIn(0, 4)
            s.timeUniform = j.optString("time", "")
            j.optJSONObject("extras")?.let { e -> e.keys().forEach { k -> s.extras[k] = e.optDouble(k, 0.0).toFloat() } }
            st.shaders.add(s)
            st.nextShaderId = maxOf(st.nextShaderId, s.id + 1)
        }
    }

    // ---------- Lua generation ----------

    private fun f(v: Float): String = String.format(Locale.US, "%.4f", v.toDouble()).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    private fun active(st: StageState) = st.shaders.filter { it.enabled }

    /** Lines that go inside onCreatePost (indented with 4 spaces). */
    fun luaCreate(st: StageState): String {
        val list = active(st)
        if (list.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("    -- ===== shaders (ModBridge) =====\n")
        sb.append("    addHaxeLibrary('ShaderFilter', 'openfl.filters')\n")
        for (s in list) {
            sb.append("    initLuaShader('${s.shaderName}')\n")
            sb.append("    makeLuaSprite('${s.tag}')\n")
            sb.append("    setSpriteShader('${s.tag}', '${s.shaderName}')\n")
            if (!s.imported) {
                sb.append("    setShaderFloat('${s.tag}', 'uStrength', ${f(s.strength)})\n")
                sb.append("    setShaderFloat('${s.tag}', 'uStability', ${f(s.stability)})\n")
                sb.append("    setShaderFloat('${s.tag}', 'uSize', ${f(s.size)})\n")
                sb.append("    setShaderFloat('${s.tag}', 'uWeight', ${f(s.weight)})\n")
                sb.append("    setShaderFloat('${s.tag}', 'uAngle', ${f((s.angle * PI / 180.0).toFloat())})\n")
                sb.append("    setShaderFloat('${s.tag}', 'uShape', ${s.shape})\n")
                sb.append("    setShaderFloatArray('${s.tag}', 'uCenter', {${f(s.cx)}, ${f(s.cy)}})\n")
            }
            for ((k, v) in s.extras) sb.append("    setShaderFloat('${s.tag}', '$k', ${f(v)})\n")
        }
        fun cam(name: String, items: List<ShaderInst>) {
            if (items.isEmpty()) return
            val arr = items.joinToString(", ") { "new ShaderFilter(game.modchartSprites.get('${it.tag}').shader)" }
            sb.append("    runHaxeCode(\"game.$name.setFilters([$arr]);\")\n")
        }
        cam("camGame", list.filter { it.camera == 0 || it.camera == 2 })
        cam("camHUD", list.filter { it.camera == 1 || it.camera == 2 })
        return sb.toString()
    }

    /** Whole onUpdatePost function (time uniforms) or empty text when no active shader needs it. */
    fun luaUpdate(st: StageState): String {
        val list = active(st).filter { !it.imported || it.timeUniform.isNotEmpty() }
        if (list.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("\nlocal mbTime = 0\nfunction onUpdatePost(elapsed)\n    if curStage ~= MB_STAGE then return end\n    mbTime = mbTime + elapsed\n")
        for (s in list) sb.append("    setShaderFloat('${s.tag}', '${if (s.imported) s.timeUniform else "iTime"}', mbTime)\n")
        sb.append("end\n")
        return sb.toString()
    }

    /** Shader files that must exist in the mod for the current list. */
    fun filesToWrite(st: StageState): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        for (s in active(st)) if (!s.imported) {
            val p = preset(s.key) ?: continue
            out["shaders/MB_${p.key}.frag"] = presetSource(p).toByteArray(Charsets.UTF_8)
        }
        return out
    }
}
