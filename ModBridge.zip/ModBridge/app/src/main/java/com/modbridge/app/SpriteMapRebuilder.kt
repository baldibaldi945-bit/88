package com.modbridge.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Reconstructs TexturePacker-style sprite maps and Adobe Animate-like Animation.json
 * into Psych Sparrow atlases, character JSON, and FNMM per-frame PNG strips.
 *
 * The animation format has several dialects. Unknown fields are preserved in a report;
 * each detected atlas is rebuilt independently. FF references remain tied to the original source
 * sprite-array order. Source assets are retained on failure.
 */
internal object SpriteMapRebuilder {
    data class Result(val archive: ByteArray, val atlases: Int, val frames: Int, val warnings: List<String>)
    private data class Sprite(
        val name: String, val x: Int, val y: Int, val w: Int, val h: Int, val rotated: Boolean,
        val trimX: Int = 0, val trimY: Int = 0, val sourceW: Int = w, val sourceH: Int = h
    )
    private data class TimelineRef(val startFrame: Int, val duration: Int, val spriteIndex: Int, val x: Int, val y: Int)

    fun process(input: ByteArray): Result {
        val candidates = findAtlasJsonPaths(input)
        if (candidates.isEmpty()) return Result(input, 0, 0, emptyList())
        var current = input
        var atlasCount = 0
        var frameCount = 0
        val allWarnings = mutableListOf<String>()
        for (candidate in candidates) {
            val converted = processSingle(current, candidate, candidates.size)
            if (converted.atlases > 0) {
                current = converted.archive
                atlasCount += converted.atlases
                frameCount += converted.frames
            }
            allWarnings += converted.warnings
        }
        return Result(current, atlasCount, frameCount, allWarnings.distinct())
    }

    private fun findAtlasJsonPaths(input: ByteArray): List<String> {
        val found = mutableListOf<String>()
        ZipInputStream(ByteArrayInputStream(input)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && safe(entry.name) && entry.name.endsWith(".json", true)) {
                    val data = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val n = zip.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > 8 * 1024 * 1024) break
                        data.write(buffer, 0, n)
                    }
                    val source = data.toByteArray().toString(Charsets.UTF_8).trimStart('\uFEFF')
                    if (source.contains("\"ATLAS\"") || source.contains("\"frames\"") && source.contains("\"meta\"")) {
                        val parsed = runCatching { JSONObject(source) }.getOrNull()
                        if (parsed != null && parseSprites(parsed).isNotEmpty()) found += entry.name
                    }
                }
                zip.closeEntry()
            }
        }
        return found.distinct()
    }

    private fun processSingle(input: ByteArray, selectedAtlasPath: String, atlasCandidateCount: Int): Result {
        val files = linkedMapOf<String, ByteArray>()
        val warnings = mutableListOf<String>()
        try {
            ZipInputStream(ByteArrayInputStream(input)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (!e.isDirectory && safe(e.name)) {
                        val out = ByteArrayOutputStream()
                        val buf = ByteArray(32 * 1024)
                        var total = 0L
                        while (true) {
                            val n = zin.read(buf); if (n < 0) break
                            total += n
                            require(total <= 128L * 1024 * 1024) { "Sprite-map input entry too large: ${e.name}" }
                            out.write(buf, 0, n)
                        }
                        files[e.name] = out.toByteArray()
                    }
                    zin.closeEntry()
                }
            }
        } catch (t: Throwable) {
            return Result(input, 0, 0, listOf("Sprite-map reader: ${t.message ?: "archive read failed"}; original assets preserved."))
        }

        val jsonPaths = files.keys.filter { it.endsWith(".json", true) }
        val atlasJsonPath = selectedAtlasPath.takeIf { it in files }
            ?: return Result(input, 0, 0, listOf("Sprite-map file '$selectedAtlasPath' disappeared during reconstruction; original archive retained."))

        val atlasJson = runCatching { JSONObject(files[atlasJsonPath]!!.toString(Charsets.UTF_8).trimStart('\uFEFF')) }.getOrNull()
            ?: return Result(input, 0, 0, listOf("Sprite-map JSON is malformed; source kept unchanged."))
        val sprites = parseSprites(atlasJson)
        if (sprites.isEmpty()) return Result(input, 0, 0, listOf("No usable sprite rectangles found in sprite-map JSON."))

        val imagePath = findAtlasImage(files, atlasJsonPath, atlasJson)
        if (imagePath == null) return Result(input, 0, 0, listOf("Sprite-map image not found beside its JSON; source kept unchanged."))
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val imageBytes = files[imagePath]!!
        BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0 ||
            bounds.outWidth.toLong() * bounds.outHeight > 45_000_000L) {
            return Result(input, 0, 0, listOf("Sprite-map image dimensions are invalid or exceed the 45 MP safety limit."))
        }
        val atlasBitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
            ?: return Result(input, 0, 0, listOf("Unable to decode sprite-map image."))
        val valid = sprites.filter {
            it.x >= 0 && it.y >= 0 && it.w > 0 && it.h > 0 &&
                it.x + it.w <= atlasBitmap.width && it.y + it.h <= atlasBitmap.height
        }
        if (valid.size != sprites.size) warnings += "${sprites.size - valid.size} rectangles were outside the atlas and were ignored."

        val atlasDirectory = atlasJsonPath.substringBeforeLast('/', "")
        val animationCandidates = jsonPaths.filter {
            it.substringAfterLast('/').equals("Animation.json", true) || it.substringAfterLast('/').equals("animation.json", true)
        }
        val animationPath = animationCandidates.firstOrNull { it.substringBeforeLast('/', "") == atlasDirectory }
            ?: animationCandidates.singleOrNull()?.takeIf { atlasCandidateCount == 1 }
        val animationRoot = animationPath?.let { runCatching { JSONObject(files[it]!!.toString(Charsets.UTF_8).trimStart('\uFEFF')) }.getOrNull() }
        val baseCharacterName = sanitize(
            animationRoot?.optJSONObject("AN")?.optString("SN")?.takeIf { it.isNotBlank() }
                ?: animationRoot?.optJSONObject("AN")?.optString("N")?.takeIf { it.isNotBlank() }
                ?: atlasJsonPath.substringAfterLast('/').substringBeforeLast('.')
        )
        var charName = baseCharacterName
        // If an earlier atlas in this same archive already generated this character name,
        // keep both atlases and give the later one a deterministic path-derived suffix.
        if ("images/characters/$charName.png" in files && "characters/$charName.json" in files &&
            files["conversion-report.txt"]?.toString(Charsets.UTF_8)?.contains("SpriteMapRebuilder atlas: $charName") == true) {
            val suffix = sanitize(atlasJsonPath.substringAfterLast('/').substringBeforeLast('.'))
            val stem = "${baseCharacterName}-${suffix}"
            charName = stem
            var disambiguator = 2
            while ("images/characters/$charName.png" in files || "characters/$charName.json" in files) {
                charName = "${stem}-${disambiguator++}"
            }
        } else if ("images/characters/$charName.png" in files && "characters/$charName.json" !in files) {
            charName = "${charName}-spritemap"
        }
        val numericOrder = valid.isNotEmpty() && valid.all { it.name.toLongOrNull() != null }
        // Adobe Animate FF is a zero-based index into the source atlas frame list;
        // do not reorder that mapping just because the output filenames are numeric.
        val validIdentity = valid.toSet()
        val frameByIndex = sprites.withIndex().filter { it.value in validIdentity }.associate { it.index to it.value }
        val imageOut = ByteArrayOutputStream()
        // Reuse the original atlas pixels: Sparrow XML rectangles remain lossless and compact.
        atlasBitmap.compress(Bitmap.CompressFormat.PNG, 100, imageOut)
        atlasBitmap.recycle()
        files["images/characters/$charName.png"] = imageOut.toByteArray()

        // FF indexes the original source JSON array. Build animation-prefixed aliases
        // into the same atlas so Psych's addByIndices can resolve every generated frame.
        val timelineGroups = animationRoot?.let { collectTimelineGroups(it, frameByIndex) }.orEmpty()
        val anims = extractAnimations(animationRoot, frameByIndex, true, warnings)
        files["images/characters/$charName.xml"] = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<TextureAtlas imagePath=\"$charName.png\">\n")
            valid.forEach { s -> appendSubTexture(s, s.name) }
            for (ai in 0 until anims.length()) {
                val anim = anims.optJSONObject(ai) ?: continue
                val sourceSymbol = anim.optString("sourceSymbol")
                val prefix = anim.optString("name")
                val sequence = timelineGroups[sourceSymbol].orEmpty()
                var generatedIndex = 0
                for (ref in sequence) repeat(ref.duration) {
                    val frame = frameByIndex[ref.spriteIndex] ?: return@repeat
                    appendSubTexture(frame, "$prefix$generatedIndex")
                    generatedIndex++
                }
            }
            append("</TextureAtlas>\n")
        }.toByteArray(Charsets.UTF_8)

        val charJson = JSONObject()
            .put("image", "characters/$charName")
            .put("healthicon", charName)
            .put("scale", 1)
            .put("sing_duration", 4)
            .put("camera_position", JSONArray().put(0).put(0))
            .put("position", JSONArray().put(0).put(0))
            .put("flip_x", false)
            .put("no_antialiasing", false)
            .put("animations", anims)
        val existingCharacterPath = "characters/$charName.json"
        if (existingCharacterPath in files) {
            val existing = runCatching { JSONObject(files[existingCharacterPath]!!.toString(Charsets.UTF_8).trimStart('\uFEFF')) }.getOrElse { JSONObject() }
            // Keep author-provided offsets/scales/other metadata, but point the character at the rebuilt Sparrow atlas.
            existing.put("image", "characters/$charName")
            existing.put("healthicon", existing.optString("healthicon").ifBlank { charName })
            if (anims.length() > 0) existing.put("animations", anims)
            files[existingCharacterPath] = existing.toString(2).toByteArray(Charsets.UTF_8)
            warnings += "Existing character JSON for '$charName' was adapted to the rebuilt Sparrow atlas; original metadata fields were kept."
        } else files[existingCharacterPath] = charJson.toString(2).toByteArray(Charsets.UTF_8)

        val report = files["conversion-report.txt"]?.toString(Charsets.UTF_8).orEmpty()
        files["conversion-report.txt"] = (report + "\nSpriteMapRebuilder atlas: $charName\nSource JSON: $atlasJsonPath\nSource image: $imagePath\nAnimations: ${anims.length()}\n" + warnings.joinToString("\n") { "- $it" } + "\n").toByteArray()
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip -> files.forEach { (name, bytes) ->
            zip.putNextEntry(ZipEntry(name)); zip.write(bytes); zip.closeEntry()
        } }
        return Result(out.toByteArray(), 1, valid.size, warnings)
    }

    private fun collectTimelineGroups(root: JSONObject, frames: Map<Int, Sprite>): Map<String, List<TimelineRef>> {
        val groups = linkedMapOf<String, MutableList<TimelineRef>>()
        val layers = root.optJSONObject("AN")?.optJSONObject("TL")?.optJSONArray("L") ?: return emptyMap()
        for (li in 0 until layers.length()) {
            val layer = layers.optJSONObject(li) ?: continue
            val frs = layer.optJSONArray("FR") ?: continue
            for (fi in 0 until frs.length()) {
                val fr = frs.optJSONObject(fi) ?: continue
                val start = fr.optInt("I", fi).coerceAtLeast(0)
                val rawDuration = fr.optInt("DU", 1)
                val duration = rawDuration.coerceIn(1, 240)
                val elements = fr.optJSONArray("E") ?: continue
                for (ei in 0 until elements.length()) {
                    val si = elements.optJSONObject(ei)?.optJSONObject("SI") ?: continue
                    val name = si.optString("SN").trim()
                    val index = si.optInt("FF", -1)
                    if (name.isBlank() || index !in frames.keys) continue
                    val matrix = si.optJSONArray("M3D")
                    val x = matrix?.optDouble(12, 0.0)?.toInt() ?: 0
                    val y = matrix?.optDouble(13, 0.0)?.toInt() ?: 0
                    groups.getOrPut(name) { mutableListOf() }.add(TimelineRef(start, duration, index, x, y))
                }
            }
        }
        return groups.mapValues { (_, sequence) -> sequence.sortedBy { it.startFrame } }
    }

    private fun extractAnimations(root: JSONObject?, frames: Map<Int, Sprite>, reliable: Boolean, warnings: MutableList<String>): JSONArray {
        val result = JSONArray()
        if (root == null || !reliable) return result
        val groups = collectTimelineGroups(root, frames)
        val usedPrefixes = mutableSetOf<String>()
        groups.forEach { (sourceName, sequence) ->
            if (sequence.isEmpty()) return@forEach
            var prefix = animationPrefix(sourceName)
            if (!usedPrefixes.add(prefix)) {
                prefix = "${prefix}_${usedPrefixes.size + 1}"
                usedPrefixes.add(prefix)
            }
            val indices = JSONArray()
            val sourceIndices = JSONArray()
            val frameOffsets = JSONArray()
            var generated = 0
            for (ref in sequence) repeat(ref.duration) {
                if (generated < 12000) {
                    indices.put(generated)
                    sourceIndices.put(ref.spriteIndex)
                    frameOffsets.put(JSONArray().put(ref.x).put(ref.y))
                    generated++
                }
            }
            if (indices.length() == 0) return@forEach
            val first = sequence.first()
            result.put(JSONObject()
                .put("anim", prefix)
                .put("name", prefix)
                .put("fps", 24)
                .put("loop", !sourceName.contains("DELETE", true) && !sourceName.contains("END", true))
                .put("indices", indices)
                .put("offsets", JSONArray().put(first.x).put(first.y))
                .put("modbridgeSourceSymbol", sourceName)
                .put("modbridgeSourceFrameIndices", sourceIndices)
                .put("modbridgeFrameOffsets", frameOffsets))
        }
        if (result.length() == 0) warnings += "Animation.json was readable but no animation frame references matched the sprite map."
        return result
    }

    private fun parseSprites(root: JSONObject): List<Sprite> {
        val atlas = root.optJSONObject("ATLAS")
        val arr = atlas?.optJSONArray("SPRITES")
        if (arr != null) return (0 until arr.length()).mapNotNull { i ->
            val s = arr.optJSONObject(i)?.optJSONObject("SPRITE") ?: return@mapNotNull null
            val rotated = s.optBoolean("rotated")
            val packedW = s.optInt("w", 0)
            val packedH = s.optInt("h", 0)
            val originalW = if (rotated) packedH else packedW
            val originalH = if (rotated) packedW else packedH
            Sprite(
                s.optString("name"), s.optInt("x", -1), s.optInt("y", -1), packedW, packedH, rotated,
                s.optInt("trimX", s.optInt("frameOffsetX", 0)), s.optInt("trimY", s.optInt("frameOffsetY", 0)),
                s.optInt("frameWidth", s.optInt("sourceWidth", originalW)),
                s.optInt("frameHeight", s.optInt("sourceHeight", originalH))
            )
        }
        val frames = root.optJSONObject("frames") ?: return emptyList()
        return frames.keys().asSequence().mapNotNull { name ->
            val f = frames.optJSONObject(name) ?: return@mapNotNull null
            val r = f.optJSONObject("frame") ?: f
            val sourceRect = f.optJSONObject("spriteSourceSize")
            val sourceSize = f.optJSONObject("sourceSize")
            val rotated = f.optBoolean("rotated")
            val packedW = r.optInt("w", 0)
            val packedH = r.optInt("h", 0)
            val unrotatedW = if (rotated) packedH else packedW
            val unrotatedH = if (rotated) packedW else packedH
            Sprite(
                name.substringBeforeLast('.'), r.optInt("x", -1), r.optInt("y", -1), packedW, packedH, rotated,
                sourceRect?.optInt("x", 0) ?: 0, sourceRect?.optInt("y", 0) ?: 0,
                sourceSize?.optInt("w", sourceRect?.optInt("w", unrotatedW) ?: unrotatedW) ?: unrotatedW,
                sourceSize?.optInt("h", sourceRect?.optInt("h", unrotatedH) ?: unrotatedH) ?: unrotatedH
            )
        }.toList()
    }

    private fun StringBuilder.appendSubTexture(sprite: Sprite, name: String) {
        append("  <SubTexture name=\"${xml(name)}\" x=\"${sprite.x}\" y=\"${sprite.y}\" width=\"${sprite.w}\" height=\"${sprite.h}\"")
        if (sprite.rotated) append(" rotated=\"true\"")
        append(" frameX=\"${-sprite.trimX}\" frameY=\"${-sprite.trimY}\" frameWidth=\"${sprite.sourceW}\" frameHeight=\"${sprite.sourceH}\"/>\n")
    }

    private fun animationPrefix(symbol: String): String = symbol
        .replace(Regex("[^A-Za-z0-9_]"), "_")
        .trim('_')
        .take(64)
        .ifBlank { "animation" }

    private fun hasNonTranslationTransform(root: JSONObject): Boolean {
        val layers = root.optJSONObject("AN")?.optJSONObject("TL")?.optJSONArray("L") ?: return false
        for (li in 0 until layers.length()) {
            val frames = layers.optJSONObject(li)?.optJSONArray("FR") ?: continue
            for (fi in 0 until frames.length()) {
                val elements = frames.optJSONObject(fi)?.optJSONArray("E") ?: continue
                for (ei in 0 until elements.length()) {
                    val matrix = elements.optJSONObject(ei)?.optJSONObject("SI")?.optJSONArray("M3D") ?: continue
                    if (matrix.length() < 16) continue
                    for (index in 0 until 16) {
                        val expected = when (index) { 0, 5, 10, 15 -> 1.0; 12, 13 -> matrix.optDouble(index, 0.0); else -> 0.0 }
                        if (kotlin.math.abs(matrix.optDouble(index, expected) - expected) > 0.0001) return true
                    }
                }
            }
        }
        return false
    }

    private fun findAtlasImage(files: Map<String, ByteArray>, jsonPath: String, json: JSONObject): String? {
        val metaImage = json.optJSONObject("meta")?.optString("image").orEmpty()
        val base = jsonPath.substringBeforeLast('/', "")
        val candidates = listOf(if (base.isBlank()) metaImage else "$base/$metaImage", jsonPath.substringBeforeLast('.') + ".png") +
            files.keys.filter { it.substringBeforeLast('/') == base && it.endsWith(".png", true) }
        return candidates.firstOrNull { it in files }
    }
    private fun safe(name: String) = !name.startsWith("/") && name.split('/').none { it == ".." || it == "." }
    private fun sanitize(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "-").trim('-').take(64).ifBlank { "rebuilt-character" }
    private fun xml(s: String) = s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;")
}
