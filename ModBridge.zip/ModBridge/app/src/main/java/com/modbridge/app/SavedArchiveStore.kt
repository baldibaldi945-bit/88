package com.modbridge.app

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Stores successful conversion outputs locally so the user can revisit or export them later. */
internal class SavedArchiveStore(private val context: Context) {
    data class Item(val fileName: String, val source: String, val savedAt: Long, val sizeBytes: Long)

    private val directory = File(context.filesDir, "saved-conversions")
    private val preferences = context.getSharedPreferences("modbridge-library", Context.MODE_PRIVATE)
    private val indexKey = "items"

    fun list(): List<Item> {
        val raw = preferences.getString(indexKey, "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: JSONArray()
        val result = mutableListOf<Item>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val name = item.optString("fileName", "")
            if (name.isBlank() || name.contains('/') || name.contains('\\')) continue
            val file = File(directory, name)
            if (!file.isFile) continue
            result += Item(
                fileName = name,
                source = item.optString("source", "Unknown"),
                savedAt = item.optLong("savedAt", 0L),
                sizeBytes = file.length()
            )
        }
        return result.sortedByDescending { it.savedAt }
    }

    fun save(bytes: ByteArray, source: String): Item {
        directory.mkdirs()
        val savedAt = System.currentTimeMillis()
        val fileName = "ModBridge-${safePart(source)}-$savedAt.zip"
        val file = File(directory, fileName)
        file.outputStream().buffered().use { it.write(bytes) }
        val item = Item(fileName, source, savedAt, file.length())
        val all = (listOf(item) + list()).take(30)
        writeIndex(all)
        val keep = all.map { it.fileName }.toSet()
        directory.listFiles()?.filter { it.isFile && it.name !in keep }?.forEach { it.delete() }
        return item
    }

    fun export(item: Item, treeUri: Uri): Boolean {
        val safeName = item.fileName.takeIf { it.matches(Regex("[A-Za-z0-9_.-]{1,160}")) } ?: return false
        val sourceFile = File(directory, safeName)
        if (!sourceFile.isFile) return false
        val tree = DocumentFile.fromTreeUri(context, treeUri) ?: return false
        tree.findFile(safeName)?.delete()
        val destination = tree.createFile("application/zip", safeName) ?: return false
        context.contentResolver.openOutputStream(destination.uri)?.use { output ->
            sourceFile.inputStream().buffered().use { input -> input.copyTo(output) }
        } ?: return false
        return true
    }

    fun delete(item: Item) {
        val safeName = item.fileName.takeIf { it.matches(Regex("[A-Za-z0-9_.-]{1,160}")) } ?: return
        File(directory, safeName).delete()
        writeIndex(list().filterNot { it.fileName == safeName })
    }

    private fun writeIndex(items: List<Item>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject()
                .put("fileName", item.fileName)
                .put("source", item.source)
                .put("savedAt", item.savedAt))
        }
        preferences.edit().putString(indexKey, array.toString()).apply()
    }

    private fun safePart(value: String) = value.replace(Regex("[^A-Za-z0-9_-]"), "-").take(40).ifBlank { "mod" }
}
