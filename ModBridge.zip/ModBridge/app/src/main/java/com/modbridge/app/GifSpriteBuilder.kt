package com.modbridge.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Movie
import android.graphics.Paint
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.LinkedHashMap
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.ceil
import kotlin.math.sqrt

/** Converts embedded GIF assets into Psych Sparrow atlases and character JSON. */
internal object GifSpriteBuilder {
    data class Result(val archive: ByteArray, val gifs: Int, val frames: Int, val warnings: List<String>)
    private data class Frame(val name: String, val bitmap: Bitmap)
    private data class Placed(val frame: Frame, val x: Int, val y: Int)

    fun process(input: ByteArray): Result {
        val files = linkedMapOf<String, ByteArray>()
        try {
            ZipInputStream(ByteArrayInputStream(input)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (!e.isDirectory && !e.name.startsWith("/") && e.name.split('/').none { it == ".." || it == "." }) {
                        val out = ByteArrayOutputStream(); val buf = ByteArray(16 * 1024); var size = 0L
                        while (true) { val n = zin.read(buf); if (n < 0) break; size += n; require(size <= 128L * 1024 * 1024); out.write(buf, 0, n) }
                        files[e.name] = out.toByteArray()
                    }
                    zin.closeEntry()
                }
            }
        } catch (t: Throwable) { return Result(input, 0, 0, listOf("GIF extraction failed: ${t.message}")) }
        val warnings = mutableListOf<String>()
        var gifCount = 0; var totalFrames = 0
        val gifPaths = files.keys.filter { it.endsWith(".gif", true) }
        for (path in gifPaths) {
            val bytes = files[path] ?: continue
            val movie = runCatching { Movie.decodeStream(ByteArrayInputStream(bytes)) }.getOrNull()
            if (movie == null || movie.width() <= 0 || movie.height() <= 0) { warnings += "GIF '$path' could not be decoded; source kept."; continue }
            val w = movie.width(); val h = movie.height()
            if (w > 2048 || h > 2048 || w.toLong() * h > 4_000_000L) { warnings += "GIF '$path' dimensions exceed the per-frame safety limit; source kept."; continue }
            val duration = movie.duration().coerceAtLeast(100)
            val count = (ceil(duration / 41.6667).toInt()).coerceIn(1, 240)
            val frames = mutableListOf<Frame>()
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            for (i in 0 until count) {
                val frame = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(frame)
                movie.setTime((i * duration / count).coerceAtMost(duration - 1))
                movie.draw(canvas, 0f, 0f, paint)
                frames += Frame("frame${i.toString().padStart(4, '0')}", frame)
            }
            val area = frames.sumOf { it.bitmap.width.toLong() * it.bitmap.height }
            if (area > 20_000_000L) { frames.forEach { it.bitmap.recycle() }; warnings += "GIF '$path' exceeds the practical bitmap memory budget; source kept."; continue }
            val atlasWidth = nextPowerOfTwo(ceil(sqrt(area.toDouble()) * 1.4).toInt().coerceAtLeast(w + 4)).coerceAtMost(4096)
            var x = 2; var y = 2; var rowHeight = 0
            val placed = mutableListOf<Placed>(); var failed = false
            for (frame in frames) {
                if (x + w + 2 > atlasWidth) { x = 2; y += rowHeight + 2; rowHeight = 0 }
                if (y + h + 2 > 4096) { failed = true; break }
                placed += Placed(frame, x, y); x += w + 2; rowHeight = maxOf(rowHeight, h)
            }
            if (failed) { frames.forEach { it.bitmap.recycle() }; warnings += "GIF '$path' would exceed a 4096px atlas; source kept."; continue }
            val atlasHeight = nextPowerOfTwo(y + rowHeight + 2).coerceAtMost(4096)
            val atlas = Bitmap.createBitmap(atlasWidth, atlasHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(atlas)
            placed.forEach { canvas.drawBitmap(it.frame.bitmap, it.x.toFloat(), it.y.toFloat(), paint); it.frame.bitmap.recycle() }
            val png = ByteArrayOutputStream(); atlas.compress(Bitmap.CompressFormat.PNG, 100, png); atlas.recycle()
            val baseId = sanitize(path.substringAfterLast('/').substringBeforeLast('.'))
            var id = baseId
            var suffix = 2
            while ("images/characters/$id.png" in files || "characters/$id.json" in files || "data/modbridge-gif/$id.json" in files) {
                id = "${baseId}-gif-${suffix++}"
            }
            files["images/characters/$id.png"] = png.toByteArray()
            files["images/characters/$id.xml"] = buildString {
                append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<TextureAtlas imagePath=\"$id.png\">\n")
                placed.forEach { append("  <SubTexture name=\"${it.frame.name}\" x=\"${it.x}\" y=\"${it.y}\" width=\"$w\" height=\"$h\" frameX=\"0\" frameY=\"0\" frameWidth=\"$w\" frameHeight=\"$h\"/>\n") }
                append("</TextureAtlas>\n")
            }.toByteArray()
            val indices = JSONArray(); placed.forEach { indices.put(it.frame.name) }
            val animation = JSONObject().put("anim", id).put("name", id).put("fps", count * 1000.0 / duration)
                .put("loop", true).put("indices", indices).put("offsets", JSONArray().put(0).put(0))
            val char = JSONObject().put("image", "characters/$id").put("healthicon", id).put("scale", 1)
                .put("sing_duration", 4).put("camera_position", JSONArray().put(0).put(0))
                .put("position", JSONArray().put(0).put(0)).put("flip_x", false)
                .put("no_antialiasing", false).put("animations", JSONArray().put(animation))
            files["characters/$id.json"] = char.toString(2).toByteArray()
            files["data/modbridge-gif/$id.json"] = JSONObject().put("sourceGif", path).put("frameCount", count).put("durationMs", duration).toString(2).toByteArray()
            gifCount++; totalFrames += count
        }
        if (gifCount == 0) return Result(input, 0, 0, warnings)
        files["conversion-report.txt"] = ((files["conversion-report.txt"]?.toString(Charsets.UTF_8).orEmpty()) +
            "\nGIF Sprite Builder:\nGIFs converted: $gifCount\nFrames generated: $totalFrames\n" + warnings.joinToString("\n") { "- $it" } + "\n").toByteArray()
        val out = ByteArrayOutputStream(); ZipOutputStream(out).use { zip -> files.forEach { (n, b) -> zip.putNextEntry(ZipEntry(n)); zip.write(b); zip.closeEntry() } }
        return Result(out.toByteArray(), gifCount, totalFrames, warnings)
    }
    private fun sanitize(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "-").trim('-').take(64).ifBlank { "gif-animation" }
    private fun nextPowerOfTwo(value: Int): Int { var v = 1; while (v < value && v < 8192) v = v shl 1; return v }
}
