package com.modbridge.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.LinkedHashMap
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.ceil
import kotlin.math.sqrt

/**
 * Builds Sparrow atlases from real FNMM sprite.json descriptors.
 * FNMM type-1 sprites store each animation as a horizontal strip in <id>/<animationIndex>.png;
 * the descriptor's data[index].num gives the number of frames in that strip.
 */
internal object AndroidSpriteSheetBuilder {
    private const val MAX_BUILDER_ARCHIVE = 256L * 1024 * 1024
    private const val MAX_BUILDER_ENTRY = 128L * 1024 * 1024
    private const val MAX_BUILDER_TOTAL = 384L * 1024 * 1024
    private const val MAX_SOURCE_SHEET_PIXELS = 16_000_000L
    private const val MAX_PACKED_FRAME_PIXELS = 12_000_000L

    data class Result(val archive: ByteArray, val atlases: Int, val frames: Int, val warnings: List<String>)
    private data class Frame(val animation: String, val index: Int, val bitmap: Bitmap)
    private data class Placement(val frame: Frame, val x: Int, val y: Int, val width: Int, val height: Int)

    fun process(input: ByteArray): Result {
        if (input.size.toLong() > MAX_BUILDER_ARCHIVE) {
            return Result(input, 0, 0, listOf("تجاوز الأرشيف حد Sprite Builder الآمن؛ تم الاحتفاظ بملف التحويل دون فك الصور مجدداً."))
        }
        val files = LinkedHashMap<String, ByteArray>()
        var expandedBytes = 0L
        var entriesRead = 0
        try {
            ZipInputStream(ByteArrayInputStream(input)).use { zin ->
                while (true) {
                    val entry = zin.nextEntry ?: break
                    entriesRead++
                    if (entriesRead > 20_000) throw IllegalArgumentException("Sprite builder entry limit exceeded")
                    if (!entry.isDirectory && !entry.name.startsWith("/") && entry.name.split('/').none { it == ".." || it == "." }) {
                        val buffer = ByteArrayOutputStream()
                        val chunk = ByteArray(16 * 1024)
                        var entryBytes = 0L
                        while (true) {
                            val n = zin.read(chunk)
                            if (n < 0) break
                            entryBytes += n
                            expandedBytes += n
                            if (entryBytes > MAX_BUILDER_ENTRY || expandedBytes > MAX_BUILDER_TOTAL) {
                                throw IllegalArgumentException("Sprite builder expanded archive limit exceeded")
                            }
                            buffer.write(chunk, 0, n)
                        }
                        files[entry.name] = buffer.toByteArray()
                    }
                    zin.closeEntry()
                }
            }
        } catch (error: Throwable) {
            return Result(input, 0, 0, listOf("تعذر تشغيل Sprite Builder ضمن حدود الذاكرة الآمنة: ${error.message ?: "unknown"}. تم الاحتفاظ بملف ZIP الأصلي."))
        }

        val warnings = mutableListOf<String>()
        val manifests = files.keys.filter { it.startsWith("data/modbridge-sprites/") && it.endsWith(".json", true) }
        if (manifests.isEmpty()) return Result(input, 0, 0, emptyList())
        var atlasCount = 0
        var frameCount = 0

        for (manifestPath in manifests) {
            val id = manifestPath.substringAfterLast('/').removeSuffix(".json")
            val manifest = runCatching { JSONObject(files[manifestPath]!!.toString(Charsets.UTF_8)) }.getOrNull()
            if (manifest == null || manifest.optInt("type", 0) != 1) {
                warnings += "Sprite '$id': وصف الإطارات غير صالح أو ليس Sprite متحركاً؛ احتفظت بالصور الأصلية."
                continue
            }
            val animationData = manifest.optJSONArray("data") ?: JSONArray()
            val frames = mutableListOf<Frame>()
            var splitFailed = false
            for (animationIndex in 0 until animationData.length()) {
                val definition = animationData.optJSONObject(animationIndex) ?: continue
                val count = definition.optString("num", definition.optInt("num", 1).toString()).toIntOrNull()?.coerceIn(1, 2000) ?: 1
                val path = "images/$id/$animationIndex.png"
                val bytes = files[path]
                if (bytes == null) {
                    warnings += "Sprite '$id': صورة الحركة $animationIndex مفقودة."
                    continue
                }
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                val sourcePixels = bounds.outWidth.toLong() * bounds.outHeight.toLong()
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0 || sourcePixels > MAX_SOURCE_SHEET_PIXELS) {
                    warnings += "Sprite '$id': أبعاد شريط $path غير صالحة أو أكبر من حد الذاكرة؛ أبقيت المصدر كما هو."
                    splitFailed = true
                    break
                }
                val sheet = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (sheet == null) {
                    warnings += "Sprite '$id': تعذر قراءة $path."
                    continue
                }
                if (sheet.width < count || sheet.width % count != 0) {
                    warnings += "Sprite '$id': عرض شريط الحركة $animationIndex لا ينقسم بالتساوي على $count إطاراً؛ أبقيت المصدر كما هو."
                    sheet.recycle()
                    splitFailed = true
                    break
                }
                val frameWidth = sheet.width / count
                if (frameWidth <= 0 || frameWidth > 4096 || sheet.height > 4096) {
                    sheet.recycle()
                    splitFailed = true
                    warnings += "Sprite '$id': أبعاد الإطار تتجاوز الحد الآمن."
                    break
                }
                for (frameIndex in 0 until count) {
                    val bitmap = runCatching { Bitmap.createBitmap(sheet, frameIndex * frameWidth, 0, frameWidth, sheet.height) }.getOrNull()
                    if (bitmap == null) { splitFailed = true; break }
                    frames += Frame("fnmm_anim$animationIndex", frameIndex, bitmap)
                }
                sheet.recycle()
                if (splitFailed) break
            }

            if (splitFailed || frames.isEmpty()) {
                frames.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
                warnings += "Sprite '$id': لم يكتمل بناء الأطلس؛ لم أحذف الصور الأصلية."
                continue
            }

            val totalArea = frames.sumOf { it.bitmap.width.toLong() * it.bitmap.height.toLong() }
            if (totalArea > MAX_PACKED_FRAME_PIXELS) {
                frames.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
                warnings += "Sprite '$id': مجموع مساحة الإطارات كبير على الذاكرة؛ أبقيت الصور الأصلية دون ضغطها في أطلس."
                continue
            }
            val maxFrameWidth = frames.maxOf { it.bitmap.width }
            val wanted = ceil(sqrt(totalArea.toDouble()) * 1.35).toInt().coerceAtLeast(maxFrameWidth + 4)
            val atlasWidth = nextPowerOfTwo(wanted.coerceAtMost(4096)).coerceAtMost(4096)
            var x = 2
            var y = 2
            var rowHeight = 0
            val placements = mutableListOf<Placement>()
            var failed = false
            for (frame in frames.sortedWith(compareByDescending<Frame> { it.bitmap.height }.thenByDescending { it.bitmap.width })) {
                if (frame.bitmap.width + 4 > atlasWidth) { failed = true; break }
                if (x + frame.bitmap.width + 2 > atlasWidth) {
                    x = 2
                    y += rowHeight + 2
                    rowHeight = 0
                }
                if (y + frame.bitmap.height + 2 > 4096) { failed = true; break }
                placements += Placement(frame, x, y, frame.bitmap.width, frame.bitmap.height)
                x += frame.bitmap.width + 2
                rowHeight = maxOf(rowHeight, frame.bitmap.height)
            }
            if (failed || placements.size != frames.size) {
                frames.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
                warnings += "Sprite '$id': الأطلس أكبر من 4096×4096؛ أبقيت ملفات المصدر ولم أستبدلها."
                continue
            }

            val atlasHeight = nextPowerOfTwo((y + rowHeight + 2).coerceAtLeast(4)).coerceAtMost(4096)
            val atlas = Bitmap.createBitmap(atlasWidth, atlasHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(atlas)
            val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            for (placement in placements) canvas.drawBitmap(placement.frame.bitmap, placement.x.toFloat(), placement.y.toFloat(), paint)
            val png = ByteArrayOutputStream()
            atlas.compress(Bitmap.CompressFormat.PNG, 100, png)
            atlas.recycle()
            frames.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }

            files["images/$id.png"] = png.toByteArray()
            val atlasXml = buildString {
                append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<TextureAtlas imagePath=\"$id.png\">\n")
                placements.sortedWith(compareBy<Placement> { it.frame.animation }.thenBy { it.frame.index }).forEach { p ->
                    val frameName = "${p.frame.animation}${p.frame.index.toString().padStart(4, '0')}"
                    append("  <SubTexture name=\"$frameName\" x=\"${p.x}\" y=\"${p.y}\" width=\"${p.width}\" height=\"${p.height}\" frameX=\"0\" frameY=\"0\" frameWidth=\"${p.width}\" frameHeight=\"${p.height}\"/>\n")
                }
                append("</TextureAtlas>\n")
            }.toByteArray(Charsets.UTF_8)
            files["images/$id.xml"] = atlasXml
            files["images/characters/$id.png"] = png.toByteArray()
            files["images/characters/$id.xml"] = atlasXml

            val animations = JSONArray()
            for (animationIndex in 0 until animationData.length()) {
                val definition = animationData.optJSONObject(animationIndex) ?: continue
                val speed = definition.optDouble("spd", 1.0).coerceIn(0.1, 8.0)
                val fps = (if (definition.optBoolean("spd_fps", false)) speed else 24.0 * speed).toInt().coerceIn(1, 120)
                val offset = definition.optJSONObject("offset") ?: JSONObject()
                animations.put(JSONObject()
                    .put("anim", fnmmAnimationName(animationIndex))
                    .put("name", "fnmm_anim$animationIndex")
                    .put("fps", fps)
                    .put("loop", definition.optBoolean("loop", true))
                    .put("offsets", JSONArray().put(offset.optDouble("x", 0.0)).put(offset.optDouble("y", 0.0))))
            }
            val character = JSONObject()
                .put("image", "characters/$id")
                .put("healthicon", id)
                .put("scale", 1)
                .put("sing_duration", 4)
                .put("camera_position", JSONArray().put(0).put(0))
                .put("position", JSONArray().put(0).put(0))
                .put("flip_x", false)
                .put("no_antialiasing", false)
                .put("animations", animations)
            files["characters/$id.json"] = character.toString(2).toByteArray(Charsets.UTF_8)

            // The packed atlas now replaces all original strip images at runtime.
            files.keys.filter { it.startsWith("images/$id/") && it.endsWith(".png", true) }.toList().forEach { files.remove(it) }
            files.remove(manifestPath)
            atlasCount++
            frameCount += placements.size
        }

        // These descriptors are ModBridge's private staging files, not Psych runtime content.
        // Remove them even on an atlas failure; the untouched strip images remain as fallback assets.
        files.keys.filter { it.startsWith("data/modbridge-sprites/") }.toList().forEach { files.remove(it) }

        val reportText = files["conversion-report.txt"]?.toString(Charsets.UTF_8).orEmpty()
        files["conversion-report.txt"] = (reportText + "\nFNMM sprite builder:\nAtlases built: $atlasCount\nFrames packed: $frameCount\n" + warnings.joinToString("\n") { "- $it" } + "\n").toByteArray(Charsets.UTF_8)
        val output = ByteArrayOutputStream()
        ZipOutputStream(output).use { zout ->
            files.forEach { (name, bytes) ->
                zout.putNextEntry(ZipEntry(name))
                zout.write(bytes)
                zout.closeEntry()
            }
        }
        return Result(output.toByteArray(), atlasCount, frameCount, warnings)
    }

    // Psych character animation names are semantic names; the atlas prefix remains fnmm_animN.
    private fun fnmmAnimationName(index: Int): String = when (index) {
        0 -> "idle"
        1 -> "singLEFT"
        2 -> "singDOWN"
        3 -> "singUP"
        4 -> "singRIGHT"
        5 -> "singLEFTmiss"
        6 -> "singRIGHTmiss"
        else -> "fnmm_anim$index"
    }

    private fun nextPowerOfTwo(value: Int): Int {
        var result = 1
        while (result < value && result < 8192) result = result shl 1
        return result
    }
}
