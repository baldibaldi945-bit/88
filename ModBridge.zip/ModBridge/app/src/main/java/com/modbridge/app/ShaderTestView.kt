package com.modbridge.app

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.os.Handler
import android.os.Looper
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Runs the shader chain on a stage snapshot with real OpenGL ES 2.0, using a small OpenFL/Flixel shim
 * (`#pragma header`, `bitmap`, `openfl_TextureCoordv`, `openfl_TextureSize`, `flixel_texture2D`).
 * Compile errors are reported through [onLog] so imported shaders can be tested before saving the mod.
 */
internal class ShaderTestView(context: Context) : GLSurfaceView(context) {
    var onLog: ((String) -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    private val r = Rend()

    init {
        setEGLContextClientVersion(2)
        setRenderer(r)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun setScene(b: Bitmap?) {
        if (b === r.scene) return
        r.scene = b; r.sceneDirty = true
    }

    fun setChain(list: List<TestPass>) { r.chain = list }

    private fun log(msg: String) { main.post { onLog?.invoke(msg) } }

    private inner class Rend : GLSurfaceView.Renderer {
        @Volatile var scene: Bitmap? = null
        @Volatile var sceneDirty = false
        @Volatile var chain: List<TestPass> = emptyList()

        private var sceneTex = 0
        private var sw = 1
        private var sh = 1
        private var vw = 1
        private var vh = 1
        private val fbo = arrayOf(IntArray(2), IntArray(2)) // [framebuffer, texture]
        private var programs: List<Int> = emptyList()
        private var compiled: List<String> = emptyList()
        private var passProg = 0
        private var passTried = false
        private val start = System.nanoTime()

        private val screenQuad = buf(floatArrayOf(-1f, -1f, 0f, 1f, 1f, -1f, 1f, 1f, -1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f))
        private val fboQuad = buf(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))

        private fun buf(a: FloatArray): FloatBuffer =
            ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { it.put(a); it.position(0) }

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            sceneTex = 0; programs = emptyList(); compiled = emptyList(); passProg = 0; passTried = false
            fbo.forEach { it[0] = 0; it[1] = 0 }
            sceneDirty = scene != null
            GLES20.glClearColor(0.08f, 0.08f, 0.1f, 1f)
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { vw = width; vh = height }

        private fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) {
                log("خطأ ترجمة الشادر: " + GLES20.glGetShaderInfoLog(s).trim().take(300))
                GLES20.glDeleteShader(s); return 0
            }
            return s
        }

        private fun program(frag: String): Int {
            val vs = shader(GLES20.GL_VERTEX_SHADER, VERT)
            val fs = shader(GLES20.GL_FRAGMENT_SHADER, buildFrag(frag))
            if (vs == 0 || fs == 0) return 0
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, vs); GLES20.glAttachShader(p, fs)
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            GLES20.glDeleteShader(vs); GLES20.glDeleteShader(fs)
            if (ok[0] == 0) { log("خطأ ربط الشادر: " + GLES20.glGetProgramInfoLog(p).trim().take(300)); GLES20.glDeleteProgram(p); return 0 }
            return p
        }

        private fun makeFbo(i: Int) {
            val t = IntArray(1); GLES20.glGenTextures(1, t, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, sw, sh, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            params()
            val f = IntArray(1); GLES20.glGenFramebuffers(1, f, 0)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, f[0])
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, t[0], 0)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            fbo[i][0] = f[0]; fbo[i][1] = t[0]
        }

        private fun params() {
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }

        private fun uploadScene(b: Bitmap) {
            if (sceneTex == 0) { val t = IntArray(1); GLES20.glGenTextures(1, t, 0); sceneTex = t[0] }
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, sceneTex)
            params()
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0)
            if (b.width != sw || b.height != sh || fbo[0][0] == 0) {
                sw = b.width; sh = b.height
                for (i in 0..1) {
                    if (fbo[i][0] != 0) { GLES20.glDeleteFramebuffers(1, intArrayOf(fbo[i][0]), 0); GLES20.glDeleteTextures(1, intArrayOf(fbo[i][1]), 0) }
                    makeFbo(i)
                }
            }
        }

        private fun recompile(list: List<TestPass>) {
            programs.forEach { if (it != 0) GLES20.glDeleteProgram(it) }
            programs = list.map { program(it.source) }
            compiled = list.map { it.source }
        }

        private fun drawPass(prog: Int, tex: Int, quad: FloatBuffer, pass: TestPass?) {
            GLES20.glUseProgram(prog)
            val pos = GLES20.glGetAttribLocation(prog, "aPosition")
            val uv = GLES20.glGetAttribLocation(prog, "aTexCoord")
            quad.position(0); GLES20.glVertexAttribPointer(pos, 2, GLES20.GL_FLOAT, false, 16, quad); GLES20.glEnableVertexAttribArray(pos)
            quad.position(2); GLES20.glVertexAttribPointer(uv, 2, GLES20.GL_FLOAT, false, 16, quad); GLES20.glEnableVertexAttribArray(uv)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "bitmap"), 0)
            GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "openfl_TextureSize"), sw.toFloat(), sh.toFloat())
            if (pass != null) {
                val t = (System.nanoTime() - start) / 1e9f
                pass.timeNames.forEach { GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, it), t) }
                pass.floats.forEach { (k, v) -> GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, k), v) }
                pass.vec2s.forEach { (k, v) -> GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, k), v.first, v.second) }
            }
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(pos); GLES20.glDisableVertexAttribArray(uv)
        }

        override fun onDrawFrame(gl: GL10?) {
            val b = scene
            if (sceneDirty && b != null && !b.isRecycled) { uploadScene(b); sceneDirty = false }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glViewport(0, 0, vw, vh)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            if (sceneTex == 0) return
            val list = chain
            if (passProg == 0 && !passTried) { passTried = true; passProg = program("#pragma header\nvoid main(){ gl_FragColor = flixel_texture2D(bitmap, openfl_TextureCoordv); }") }
            if (list.map { it.source } != compiled) recompile(list)
            val valid = list.indices.filter { programs.getOrElse(it) { 0 } != 0 }
            var input = sceneTex
            if (valid.isEmpty()) { if (passProg != 0) drawPass(passProg, input, screenQuad, null); return }
            for ((n, idx) in valid.withIndex()) {
                val last = n == valid.lastIndex
                if (last) {
                    GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0); GLES20.glViewport(0, 0, vw, vh)
                    drawPass(programs[idx], input, screenQuad, list[idx])
                } else {
                    val t = fbo[n % 2]
                    GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, t[0]); GLES20.glViewport(0, 0, sw, sh)
                    drawPass(programs[idx], input, fboQuad, list[idx])
                    input = t[1]
                }
            }
        }
    }

    companion object {
        private const val VERT = "attribute vec4 aPosition;\nattribute vec2 aTexCoord;\nvarying vec2 openfl_TextureCoordv;\n" +
            "void main(){ gl_Position = aPosition; openfl_TextureCoordv = aTexCoord; }\n"

        private const val SHIM = "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n" +
            "varying vec2 openfl_TextureCoordv;\nuniform sampler2D bitmap;\nuniform vec2 openfl_TextureSize;\n" +
            "vec4 flixel_texture2D(sampler2D b, vec2 c){ return texture2D(b, c); }\n"

        fun buildFrag(src: String): String {
            val s = src.replace(Regex("(?m)^\\s*#version.*$"), "")
            return if (s.contains("#pragma header")) s.replace("#pragma header", SHIM) else SHIM + s
        }
    }
}
