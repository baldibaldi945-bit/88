package com.modbridge.app

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Merges the user's supplied My-Mod Psych template without overwriting converted content. */
internal object PsychOutputFinalizer {
    fun apply(context: Context, converted: ByteArray, sourceName: String): ByteArray {
        val output = readArchive(converted)
        val template = context.assets.open("psych_mod_template.zip").use { readArchive(it.readBytes()) }
        for ((raw, bytes) in template) {
            val path = raw.removePrefix("My-Mod/").trimStart('/')
            if (path.isBlank()) continue
            if (path == "pack.json" && path !in output) {
                val pack = runCatching { JSONObject(bytes.toString(Charsets.UTF_8)) }.getOrElse { JSONObject() }
                pack.put("name", sourceName.replace(Regex("[^A-Za-z0-9 _-]"), " ").trim().take(48).ifBlank { "Converted Mod" })
                pack.put("description", "Converted with ModBridge. Review conversion-report.txt and test in Psych Engine.")
                output[path] = pack.toString(2).toByteArray()
            } else if (path !in output) {
                output[path] = bytes
            }
        }
        // Required directory markers stay present even when the source mod has no matching assets.
        listOf(
            "characters", "custom_events", "custom_notetypes", "data", "images", "images/achievements",
            "images/characters", "images/credits", "images/dialogue", "images/en-US", "images/icons",
            "images/menubackgrounds", "images/menucharacters", "images/menudifficulties", "images/noteSkins",
            "images/noteSplashes", "images/storymenu", "music", "scripts", "shaders", "songs", "stages", "videos", "weeks"
        ).forEach { output.putIfAbsent("$it/.keep", ByteArray(0)) }
        val zipped = ByteArrayOutputStream()
        ZipOutputStream(zipped).use { zip ->
            output.forEach { (name, bytes) ->
                if (name.startsWith("/") || name.split('/').any { it == ".." || it == "." }) return@forEach
                zip.putNextEntry(ZipEntry(name)); zip.write(bytes); zip.closeEntry()
            }
        }
        return zipped.toByteArray()
    }

    private fun readArchive(bytes: ByteArray): LinkedHashMap<String, ByteArray> = readArchiveBytes(ByteArrayInputStream(bytes))

    private fun readArchiveBytes(input: ByteArrayInputStream): LinkedHashMap<String, ByteArray> {
        val map = linkedMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && !entry.name.startsWith("/") && entry.name.split('/').none { it == ".." || it == "." }) {
                    val out = ByteArrayOutputStream()
                    val buffer = ByteArray(16 * 1024)
                    var total = 0L
                    while (true) {
                        val n = zip.read(buffer); if (n < 0) break
                        total += n
                        require(total <= 512L * 1024 * 1024) { "Psych template archive exceeds the safe expansion limit." }
                        out.write(buffer, 0, n)
                    }
                    map[entry.name] = out.toByteArray()
                }
                zip.closeEntry()
            }
        }
        return map
    }
}
