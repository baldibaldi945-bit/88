package com.modbridge.core

import kotlin.test.Test
import kotlin.test.assertTrue

class ScriptDoctorTest {
    @Test fun detectsUnbalancedLuaBlocks() {
        val report = ScriptDoctor.inspect("broken.lua", "function onCreate()\n makeLuaSprite('x','x',0,0)\n")
        assertTrue(report.warnings.any { it.contains("end") })
    }

    @Test fun reportsInvalidJson() {
        val report = ScriptDoctor.inspect("bad.json", "{ nope }")
        assertTrue(report.errors.isNotEmpty())
    }
}
