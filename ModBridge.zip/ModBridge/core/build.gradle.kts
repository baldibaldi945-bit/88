plugins { id("org.jetbrains.kotlin.jvm") }
kotlin { jvmToolchain(17) }
dependencies {
    implementation("org.json:json:20240303")
    implementation("org.apache.commons:commons-compress:1.28.0")
    testImplementation(kotlin("test"))
}
