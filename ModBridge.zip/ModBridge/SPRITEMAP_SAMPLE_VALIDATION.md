# Sprite-map sample inspected for ModBridge 1.5.0

Files supplied: `spritemap1.png`, `spritemap1.json`, `Animation.json`.

Observed facts from the supplied files:
- PNG dimensions: 4091 × 1577, RGBA.
- Sprite-map JSON contains 379 `ATLAS.SPRITES[].SPRITE` rectangles.
- All 379 rectangle bounds fit within the supplied PNG.
- `Animation.json` contains symbol data, a 1034-frame main timeline, 23 distinct referenced symbol names, and 285 distinct referenced `FF` values in the range 0–284.

Implementation:
- The image is retained as PNG atlas data and Sparrow XML is generated for each atlas rectangle.
- Numeric `FF` indices are mapped using the original source `ATLAS.SPRITES` array order (invalid rectangles are excluded without reordering surviving frames).
- A generated SubTexture alias set is emitted for each timeline symbol, using animation-prefix plus sequential frame index names so Psych Engine `indices` animations can resolve frames.
- Timeline `I` and `DU` values are expanded into repeated frame indices; per-frame source index and transform offsets are retained as ModBridge JSON metadata.
- FNMM reverse conversion reads the rebuilt Sparrow atlas/Character JSON and packs each animation into one horizontal strip with `num` matching the example FNMM format.
- Crop handling applies trim/source dimensions and rotates flagged TexturePacker rectangles.

Remaining assumption:
- The source exporter’s `FF` index semantics are assumed to be zero-based references into the source sprite-array order. This mapping must be checked in the originating authoring tool and then in the target engine. Animation symbols and frame-specific transform matrices are preserved as metadata, but arbitrary per-frame rotation/scale and engine-specific semantics are not fully reproduced.
