# مهمة مراجعة وبناء ModBridge 1.5.1

افتح المستودع كاملاً وافحص ملفات Kotlin وCompose وGradle والاختبارات، ثم نفّذ عملياً:

1. شغّل `gradle test assembleDebug` على JDK 17 وAndroid SDK 35. أصلح كل أخطاء الترجمة والاختبارات قبل تعديل الميزات.
2. اختبر Image Optimizer على PNG شفاف، PNG ملوّن، WebP، JPEG، GIF متحرك، GIF شفاف، وصورة ثابتة. تحقق من PNG palette/tRNS وGIF loop والشفافية وعدم تلف الملف.
3. اختبر Psych→FNMM على عينة Psych متعددة الأغاني والصعوبات والشخصيات والمراحل. قارن `data.json`, `scene.json`, `events.json`, `sprite.json` والـicons مع ملف FNMM المثال. لا تضع أكشن FNMM مجهولاً بالتخمين.
4. اختبر قص Sparrow مع XML يحتوي frameX/frameY/frameWidth/frameHeight وحقل rotated، واختبر character JSON موجوداً ومفقوداً، وحالات FF غير المرتبة.
5. اختبر Stage Edit على أكثر من مرحلة وأكثر من شارت. تأكد من عدم إفساد JSON الأصلي وأن القلب يعكس `mustHitSection` مرة واحدة فقط.
6. اختبر Script Lab على Lua/Haxe/JSON وأرشيف ZIP وصورة وصوت. لا تدّع تعرفاً بصرياً أو تفريغاً صوتياً؛ الأداة الحالية محلية وقائمة على القواعد.
7. راجع كل تحذير في `conversion-report.txt` وتأكد من أن الأصول غير المدعومة محفوظة أو موضّح أنها لم تتحول.
8. لا تحذف أي ميزة أو ملف أصل من الإصدار. بعد نجاح جميع الاختبارات، حدّث `FINAL_SCOPE.md` بالنتائج الفعلية وارفع artifact APK.

لا تعلن نجاح APK قبل أن يظهر تشغيل GitHub Actions أخضر ويكون `app-debug.apk` موجوداً في الـartifact.
